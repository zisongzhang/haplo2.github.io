/******************************************************************** 
** Author: Tyler Williams
** Date: 6-12-18
** Description: The Space class is the base class for Terrain, Treasure,
** and PlayerSpace. It has protected data members availabe only to its
** derived classes for object construction. It has functions for 
** construction, setting data values, getting data values, and destruction.
*********************************************************************/
#ifndef SPACE_HPP
#define SPACE_HPP

#include <iostream>
#include <string>

using std::cout;
using std::endl;
using std::string;

class Space
{
protected:
	char boardChar;
	int moveSpeed;
	string obstacleType;
	bool passed;
	bool searched;

public:
	Space* top;
	Space* right;
	Space* bottom;
	Space* left;
	
	Space();
	Space(char, int, bool);

	void setBoardChar(char);
	virtual void setObsType() = 0;
	void setPassed(bool);
	void setSearched(bool);
	char getBoardChar();
	int getMoveSpeed();
	string getObsType();
	bool getPassed();
	bool getSearched();
	virtual char getBaseSpaceChar() = 0;
	
	virtual ~Space()
	{
	}
};
#include "space.cpp"
#endif