/******************************************************************** 
** Author: Tyler Williams
** Date: 6-12-18
** Description: The Treasure class is a subclass to the Space class.
** It constructs Treasure objects with inherited data from Space. 
** It has a virtual function for getting a data member, setting a data
** member and destruction. It also has a unique function for triggering
** the game to change phases into the real game.
*********************************************************************/
#include <iostream>
#include <string>
#include <cstdlib>

#include "treasure.hpp"

using std::cout;
using std::endl;
using std::cin;
using std::string;


/*****************************************************************************
**Treasure default constructor:
**Build Treasure object with no parameters.
*****************************************************************************/
Treasure::Treasure()
{ //open default constructor
	boardChar = 'x';
	moveSpeed = 1;
	obstacleType = "";
	passed = false;
	baseSpaceChar = ' ';
} //close default constructor


/*****************************************************************************
**Treasure constructor:
**Build Treasure object with char, int, and bool parameters
*****************************************************************************/
Treasure::Treasure(char bCharIn, int speedIn, bool passIn, char baseCharIn) : Space(bCharIn, speedIn, passIn)
{ //open constructor
	baseSpaceChar = baseCharIn;
	obstacleType = "";
} //close constructor


/*****************************************************************************
**getBaseSpaceChar function:
*****************************************************************************/
char Treasure::getBaseSpaceChar()
{ //open getBaseSpaceChar function
	return baseSpaceChar;
} //close getBaseSpaceChar function


/*****************************************************************************
**setObsType function:
**Initializes the data member variable when called. Set randomly based on 
**terrain type.
*****************************************************************************/
void Treasure::setObsType()
{ //open setObsType function
	int obsNum = 0;
	if (passed == false) //locations already encountered can't have a second encounter
	{ //open if
		if (baseSpaceChar == ' ')
		{ //open 2nd if
			obstacleType = "buried";
		} //close 2nd if
		else if (baseSpaceChar == '^')
		{ //open else if
			obsNum = rand() % 2 + 1;
			switch (obsNum)
			{ //open switch
				case 1:
				{ //open case 1
					obstacleType = "cavern";
					break;
				} //close case 1
				case 2:
				{ //open case 2
					obstacleType = "rock pile";
					break;
				} //close case 2
			} //close switch
		} //close else if
		else if (baseSpaceChar == 'j')
		{ //open 2nd else if
			obsNum = rand() % 2 + 1;
			switch (obsNum)
			{ //open switch
				case 1:
				{ //open case 1
					obstacleType = "covered";
					break;
				} //close case 1
				case 2:
				{ //open case 2
					obstacleType = "snakes";
					break;
				} //close case 2
			} //close switch
		} //close 2nd else if
		else if (baseSpaceChar == '|')
		{ //open 3rd else if
			obstacleType = "swept away";
		} //close 3rd else if
	} //close if
	else
	{ //open else
		cout << "You have already cleared this area." << endl;
		cout << "You are able to pass through without incident." << endl;
	} //close else
} //close setObsType function


/*****************************************************************************
**bigTActivate function:
**Print game text to screen and return bool to calling function so game shifts
**into the real challenge.
*****************************************************************************/
bool Treasure::bigTActivate()
{ //open bigTActivate function
	bool bigTStart = false;
	cout << endl << "You reach the location marked on the map and see a large ziggurat," << endl
	<< "remnant of some long-lost civilization, rise above the surrounding land." << endl;
	cout << "You search around the base for a while and, finding nothing of interest, " << endl
	<< "climb to the top. From here you can clearly see the layout of the whole island." << endl;
	
	cout << endl << "As you orientate yourself between the map and the real landscape, you" << endl
	<< "notice two other ships anchored off the coast at two small beaches far from " << endl
	<< "the one where you washed ashore. You can see small groups landing on the island." << endl
	<< "These must be the other captains Still-Has-Both-Eyes Jack was afraid of." << endl << endl;
	
	cout << "With a renewed sense of urgency, you search around the peak of the pyramid." << endl
	<< "You find a large stone altar in the center with a face carved on the surface." << endl
	<< "There are three large empty spaces in the eyes and mouth. Under a ledge of " << endl
	<< "the altar you see a leather wrapped bundle. Quickly you unwrap it and read the " << endl
	<< "paper inside." << endl << endl;
	
	cout << "Press Enter to continue." << endl;
	cin.get();
	
	cout << endl;
	cout << "\"Well done, matey.  You have reached my secret hiding place.  This island " << endl
	<< " will serve you well as a pirate captain. If you want my full treasure, though," << endl
	<< " you must work harder to earn it. This stone altar will open to reveal a buried" << endl
	<< " hoard you have only dreamt of. The only gems capable of opening this secret door" << endl
	<< " are hidden around the island. If you can survive the dangers of the island and" << endl
	<< " collect three of these special gems, bring them back here and insert them in the" << endl
	<< " altar. The vault door will open and you will have earned the treasure inside.\"" << endl;
	
	cout << endl << "Looking at the altar again you see that there are also small x marks carved on the surface." << endl
	<< "You didn't notice before but now you can see that the shape of the altar matches the shape" << endl
	<< "of the island. You mark these x's on your map, but as you do, you hear the sounds of men" << endl
	<< "shouting to each other. Peeking over the edge of the pyramid you see a small search party" << endl
	<< "entering the edges of the clearing around the pyramid. Realizing your time here is up," << endl
	<< "you quickly rush away before you are seen, on your way to find the gems you need. As you" << endl
	<< "reach the ground you realize you left in such a rush you forgot to bring the note. You" << endl
	<< "have to assume the other searchers will be able to figure out where to find the gems." << endl;
	
	cout << endl << "You are now racing to find the treasure before the other search parties!" << endl << endl;
	
	cout << "Press Enter to continue." << endl;
	cin.get();
	
	bigTStart = true;
	return bigTStart;
} // close bigTActivate function