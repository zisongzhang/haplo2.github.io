/******************************************************************** 
** Author: Tyler Williams
** Date: 6-12-18
** Description: The PlayerSpace class is a subclass to the Space class.
** It constructs PlayerSpace objects with inherited data from Space. 
** It has a virtual function for getting a data member, setting a data
** member and destruction. 
** It has unique private data members to aid in movement. It also has
** a unique function for changing the player's linked pointers during
** movement actions.
*********************************************************************/
#include <iostream>
#include <string>
#include <cstdlib>

#include "playerSpace.hpp"

using std::cout;
using std::endl;
using std::string;


/*****************************************************************************
**PlayerSpace default constructor:
**Build PlayerSpace object with no parameters.
*****************************************************************************/
PlayerSpace::PlayerSpace()
{ //open default constructor
	boardChar = ' ';
	moveSpeed = 0;
	obstacleType = "";
	passed = false;
	top = nullptr;
	right = nullptr;
	bottom = nullptr;
	left = nullptr;
} //close default constructor


/*****************************************************************************
**PlayerSpace constructor:
**Build PlayerSpace object with char, int, bool, and Space array parameters
*****************************************************************************/
PlayerSpace::PlayerSpace(char bCharIn, int speedIn, bool passIn, Space*** & arrayIn, int playRow, int playCol) : Space(bCharIn, speedIn, passIn)
{ //open constructor
	obstacleType = "";

	north = playRow - 1;
	if (arrayIn[north][playCol] != nullptr)
	{ //open if
		top = arrayIn[north][playCol];
	} //close if

	east = playCol + 1;
	if (arrayIn[playRow][east] != nullptr)
	{ //open if
		right = arrayIn[playRow][east];
	} //close if
	
	south = playRow + 1;
	if (arrayIn[south][playCol]  != nullptr)
	{ //open if
		bottom = arrayIn[south][playCol];
	} //close if

	west = playCol - 1;
	if (arrayIn[playRow][west]  != nullptr)
	{ //open if
		left = arrayIn[playRow][west];
	} //close if
} //close constructor


/*****************************************************************************
**setObsType function:
*****************************************************************************/
void PlayerSpace::setObsType()
{ //open setObsType function
	obstacleType = "";
} //close setObsType function


/*****************************************************************************
**playerMove function:
**change linked Space pointers during movement action
*****************************************************************************/
void PlayerSpace::playerMove(Space*** & arrayIn, int playRow, int playCol)
{ //open playerMove function
	north = playRow - 1;
	if (arrayIn[north][playCol] != nullptr)
	{ //open if
		top = arrayIn[north][playCol];
	} //close if

	east = playCol + 1;
	if (arrayIn[playRow][east] != nullptr)
	{ //open if
		right = arrayIn[playRow][east];
	} //close if
	
	south = playRow + 1;
	if (arrayIn[south][playCol]  != nullptr)
	{ //open if
		bottom = arrayIn[south][playCol];
	} //close if

	west = playCol - 1;
	if (arrayIn[playRow][west]  != nullptr)
	{ //open if
		left = arrayIn[playRow][west];
	} //close if
} //close playerMove function


/*****************************************************************************
**getBaseSpaceChar function:
*****************************************************************************/
char PlayerSpace::getBaseSpaceChar()
{
	return boardChar;
}