/******************************************************************** 
** Author: Tyler Williams
** Date: 6-12-18
** Description: The Terrain class is a subclass to the Space class.
** It constructs Terrain objects with inherited data from Space. 
** It has a virtual function for getting a data member, setting a 
** data member, and destruction.
*********************************************************************/
#ifndef TERRAIN_HPP
#define TERRAIN_HPP

#include <iostream>
#include <string>

#include "space.hpp"

using std::cout;
using std::endl;
using std::string;

class Terrain : public Space
{
private:
	
	
public:
	Terrain();
	Terrain(char, int, bool);
	virtual void setObsType();
	virtual char getBaseSpaceChar();
	virtual ~Terrain()
	{
	}
};
#include "terrain.cpp"
#endif