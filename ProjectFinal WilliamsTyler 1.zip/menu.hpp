/********************************************************************** 
** Author: Tyler Williams
** Date: 6-12-18
** Description: This Menu class has functions to print text to the screen
** and sometimes to get user input for use by the calling function.
*********************************************************************/
#ifndef MENU_HPP
#define MENU_HPP

#include <iostream>
#include <string>
#include <vector>

using std::cin;
using std::cout;
using std::endl;
using std::string;
using std::vector;

class Menu
{ 
private:

public:
	int playChoice();
	void startMsg();
	void printHelp();
	int quit();
	int travelSpeed();
	int encounterDanger(string, vector<string>, int);
	void victory();
};
#include "menu.cpp"
#endif