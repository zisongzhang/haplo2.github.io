/******************************************************************** 
** Author: Tyler Williams
** Date: 6-12-18
** Description: This Danger class has functions to construct a Danger 
** object and conduct full location-based encounters. There is a function
** to start the encounter and another to complete it. There are two
** versions of each of those based on being Terrain or Treasure 
** locations.
*********************************************************************/
#include <iostream>
#include <string>
#include <vector>
#include <cstdlib>

#include "danger.hpp"

using std::cin;
using std::cout;
using std::endl;
using std::string;
using std::vector;


/*****************************************************************************
**Danger default constructor:
**Build Danger object with no parameters.
*****************************************************************************/
Danger::Danger()
{ //open default constructor
	dangerName = "";
} //close default constructor


/*****************************************************************************
**Danger constructor:
**Build Danger object with string parameter
*****************************************************************************/
Danger::Danger(string obsTypeIn)
{ //open constructor
	dangerName = obsTypeIn;
} //close constructor


/*****************************************************************************
**EncounterTreas function:
**Initiate location obstacle encounter for Treasure locations. Call Menu to 
**get and then return the user's choice in how to react to the encounter.
*****************************************************************************/
int Danger::encounterTreas(string obsTypeIn, Menu gameMenu, vector<string> vectIn, int gemNum)
{ //open EncounterTreas function
	int dangerChoice = 0;
	cout << endl;
	
	if(obsTypeIn == "buried")
	{ //open if
		cout << "You find the location where the treasure should be. In the center of the clearing" << endl
		<< "is a set of rocks arranged to look like an x. You must need to dig in the center." << endl << endl;
		dangerChoice = gameMenu.encounterDanger(obsTypeIn, vectIn, gemNum);
	} //close if
	else if(obsTypeIn == "cavern")
	{ //open else if
		cout << "You find the location where the treasure should be. There is a dark cavern entrance" << endl
		<< "in the side of the mountain slope here. You don't see any other signs where the treasure" << endl
		<< "might be. You must need to go inside to retrieve it." << endl << endl;
		dangerChoice = gameMenu.encounterDanger(obsTypeIn, vectIn, gemNum);
	} //close else if
	else if(obsTypeIn == "rock pile")
	{ //open else if
		cout << "You find the location where the treasure should be. You see what might be the corner" << endl
		<< "of a chest under a pile of large rocks. You must need to dig through the rocks." << endl << endl;
		dangerChoice = gameMenu.encounterDanger(obsTypeIn, vectIn, gemNum);
	} //close else if
	else if(obsTypeIn == "covered")
	{ //open else if
		cout << "You find the location where the treasure should be. You see what might be the corner" << endl
		<< "of a chest covered by a thick web of vines and branches. You must need to get through" << endl
		<< "the plant growth." << endl << endl;
		dangerChoice = gameMenu.encounterDanger(obsTypeIn, vectIn, gemNum);
	} //close else if
	else if(obsTypeIn == "snakes")
	{ //open else if
		cout << "You find the location where the treasure should be. A chest sits in a small depression" << endl
		<< "in the ground, which is full of slithering snakes. You must need to get rid of the snakes." << endl << endl;
		dangerChoice = gameMenu.encounterDanger(obsTypeIn, vectIn, gemNum);
	} //close else if
	else if(obsTypeIn == "swept away")
	{ //open else if
		cout << "You find the location where the treasure should be. In the middle of this stretch of" << endl
		<< "the river, there is a small island. The current looks dangerous. You don't see any other" << endl
		<< "signs where the treasure might be. You must need to get to the island to retrieve it." << endl << endl;
		dangerChoice = gameMenu.encounterDanger(obsTypeIn, vectIn, gemNum);
	} //close else if

	return dangerChoice;
} //close EncounterTreas function


/*****************************************************************************
**resolveTreas function:
**Complete location obstacle encounter for Treasure locations with value 
**returned by Encounter function above. Compare obstacle type to inventory, 
**and return a value representing how much time is spent on the encounter.
**Some items negate the encounter's impact, some reduce it, and some don't
**help at all.
*****************************************************************************/
int Danger::resolveTreas(int dangerChoice, string obsTypeIn, vector<string> vectIn, bool &defeat)
{ //open ResolveTreas function
	int resolution = 0;
	cout << endl;
	
	if(obsTypeIn == "buried")
	{ //open if
		switch(dangerChoice)
		{ //open switch
			case 1:
			{ //open case 1
				resolution = 2;
				cout << "Without using a shovel it takes two hours and much painful work, but" << endl
				<< "you manage to clear away enough dirt to retrieve the gem from the chest." << endl << endl;
				break;
			} //close case 1
			case 2:
			{ //open case 2
				if (vectIn[0] == "shovel")
				{ //open 2nd if
					cout << "Using your shovel you clear the dirt away in no time. You manage to" << endl
					<< "retrieve the gem from the chest." << endl << endl;
				} //close 2nd if
				else if (vectIn[0] == "pickax")
				{ //open else if
					resolution = 1;
					cout << "Using a pickax is better than just your hands, but not as good as" << endl
					<< "a shovel.  It takes one hour and much hard work, but you manage to" << endl
					<< "clear away enough dirt to retrieve the gem from the chest." << endl << endl;
				} //close else if
				else
				{ //open else
					resolution = 2;
					cout << "Without using a shovel it takes two hours and much painful work, but" << endl
					<< "you manage to clear away enough dirt to retrieve the gem from the chest." << endl << endl;
				} //close else
				break;
			} //close case 2
			case 3:
			{ //open case 3
				if (vectIn[1] == "shovel")
				{ //open 3rd if
					cout << "Using your shovel you clear the dirt away in no time. You manage to" << endl
					<< "retrieve the gem from the chest." << endl << endl;
				} //close 3rd if
				else if (vectIn[1] == "pickax")
				{ //open else if
					resolution = 1;
					cout << "Using a pickax is better than just your hands, but not as good as" << endl
					<< "a shovel.  It takes one hour and much hard work, but you manage to" << endl
					<< "clear away enough dirt to retrieve the gem from the chest." << endl << endl;
				} //close else if
				else
				{ //open else
					resolution = 2;
					cout << "Without using a shovel it takes two hours and much painful work, but" << endl
					<< "you manage to clear away enough dirt to retrieve the gem from the chest." << endl << endl;
				} //close else
				break;
			} //close case 3
		} //close switch
	} //close if
	else if(obsTypeIn == "cavern")
	{ //open else if
		switch(dangerChoice)
		{ //open switch
			case 1:
			{ //open case 1
				resolution = 3;
				cout << "Without using a torch it takes three hours and much painful searching" << endl
				<< "in the dark, but you manage to find the chest and retrieve the gem." << endl << endl;
				break;
			} //close case 1
			case 2:
			{ //open case 2
				if (vectIn[0] == "torch")
				{ //open if
					cout << "Using your torch to search the cavern you find the chest in no time." << endl
					<< "You manage to retrieve the gem from the chest." << endl << endl;
				} //close if
				else
				{ //open else
					resolution = 3;
					cout << "Without using a torch it takes three hours and much painful searching" << endl
					<< "in the dark, but you manage to find the chest and retrieve the gem." << endl << endl;
				} //close else
				break;
			} //close case 2
			case 3:
			{ //open case 3
				if (vectIn[1] == "torch")
				{ //open 3rd if
					cout << "Using your torch to search the cavern you find the chest in no time." << endl
					<< "You manage to retrieve the gem from the chest." << endl << endl;
				} //close 3rd if
				else
				{ //open else
					resolution = 3;
					cout << "Without using a torch it takes three hours and much painful searching" << endl
					<< "in the dark, but you manage to find the chest and retrieve the gem." << endl << endl;
				} //close else
				break;
			} //close case 3
		} //close switch
	} //close else if
	else if(obsTypeIn == "rock pile")
	{ //open 2nd else if
		switch(dangerChoice)
		{ //open switch
			case 1:
			{ //open case 1
				resolution = 2;
				cout << "Without using a pickax it takes two hours and much painful work, but" << endl
				<< "you manage to clear away enough rocks to retrieve the gem from the chest." << endl << endl;
				break;
			} //close case 1
			case 2:
			{ //open case 2
				if (vectIn[0] == "pickax")
				{ //open if
					cout << "Using your pickax you clear the rocks away in no time. You manage to" << endl
					<< "retrieve the gem from the chest." << endl << endl;
				} //close if
				else if (vectIn[0] == "shovel")
				{ //open else if
					resolution = 1;
					cout << "Using a shovel is better than just your hands, but not as good as" << endl
					<< "a pickax.  It takes one hour and much hard work, but you manage to" << endl
					<< "clear away enough rocks to retrieve the gem from the chest." << endl << endl;
				} //close else if
				else
				{ //open else
					resolution = 2;
					cout << "Without using a pickax it takes two hours and much painful work, but" << endl
					<< "you manage to clear away enough rocks to retrieve the gem from the chest." << endl << endl;
				} //close else
				break;
			} //close case 2
			case 3:
			{ //open case 3
				if (vectIn[1] == "pickax")
				{ //open 3rd if
					cout << "Using your pickax you clear the rocks away in no time. You manage to" << endl
					<< "retrieve the gem from the chest." << endl << endl;
				} //close 3rd if
				else if (vectIn[1] == "shovel")
				{ //open else if
					resolution = 1;
					cout << "Using a shovel is better than just your hands, but not as good as" << endl
					<< "a pickax.  It takes one hour and much hard work, but you manage to" << endl
					<< "clear away enough dirt to retrieve the gem from the chest." << endl << endl;
				} //close else if
				else
				{ //open else
					resolution = 2;
					cout << "Without using a pickax it takes two hours and much painful work, but" << endl
					<< "you manage to clear away enough rocks to retrieve the gem from the chest." << endl << endl;
				} //close else
				break;
			} //close case 3
		} //close switch
	} //close 2nd else if
	else if(obsTypeIn == "covered")
	{ //open 3rd else if
		switch(dangerChoice)
		{ //open switch
			case 1:
			{ //open case 1
				resolution = 2;
				cout << "Without using a machete it takes two hours and much painful work, but" << endl
				<< "you manage to clear away enough rocks to retrieve the gem from the chest." << endl << endl;
				break;
			} //close case 1
			case 2:
			{ //open case 2
				if (vectIn[0] == "machete")
				{ //open if
					cout << "Using your machete you clear the plants away in no time. You manage to" << endl
					<< "retrieve the gem from the chest." << endl << endl;
				} //close if
				else if (vectIn[0] == "shovel")
				{ //open else if
					resolution = 1;
					cout << "Using a shovel is better than just your hands, but not as good as" << endl
					<< "a machete.  It takes one hour and much hard work, but you manage to" << endl
					<< "clear away enough plants to retrieve the gem from the chest." << endl << endl;
				} //close else if
				else
				{ //open else
					resolution = 2;
					cout << "Without using a machete it takes two hours and much painful work, but" << endl
					<< "you manage to clear away enough plants to retrieve the gem from the chest." << endl << endl;
				} //close else
				break;
			} //close case 2
			case 3:
			{ //open case 3
				if (vectIn[1] == "machete")
				{ //open 3rd if
					cout << "Using your machete you clear the rocks away in no time. You manage to" << endl
					<< "retrieve the gem from the chest." << endl << endl;
				} //close 3rd if
				else if (vectIn[1] == "shovel")
				{ //open else if
					resolution = 1;
					cout << "Using a shovel is better than just your hands, but not as good as" << endl
					<< "a machete.  It takes one hour and much hard work, but you manage to" << endl
					<< "clear away enough plants to retrieve the gem from the chest." << endl << endl;
				} //close else if
				else
				{ //open else
					resolution = 2;
					cout << "Without using a machete it takes two hours and much painful work, but" << endl
					<< "you manage to clear away enough plants to retrieve the gem from the chest." << endl << endl;
				} //close else
				break;
			} //close case 3
		} //close switch
	} //close 3rd else if
	else if(obsTypeIn == "snakes")
	{ //open 4th else if
		switch(dangerChoice)
		{ //open switch
			case 1:
			{ //open case 1
				resolution = 3;
				cout << "Without using a torch it takes three hours and much dangerous work using" << endl
				<< "sticks to move the snakes individually, but you manage to clear away enough " << endl
				<< "to retrieve the gem from the chest." << endl << endl;
				break;
			} //close case 1
			case 2:
			{ //open case 2
				if (vectIn[0] == "torch")
				{ //open if
					cout << "Using your torch you scare the snakes away in no time. You manage to" << endl
					<< "retrieve the gem from the chest." << endl << endl;
				} //close if
				else if (vectIn[0] == "shovel")
				{ //open else if
					resolution = 1;
					cout << "Using a shovel is better than just your hands, but not as good as" << endl
					<< "a torch.  It takes one hour and much hard work, but you manage to" << endl
					<< "clear away enough snakes to retrieve the gem from the chest." << endl << endl;
				} //close else if
				else if (vectIn[0] == "machete")
				{ //open 2nd else if
					resolution = 1;
					cout << "Using a machete is better than just your hands, but not as good as" << endl
					<< "a torch.  It takes one hour and much hard work, but you manage to" << endl
					<< "clear away enough snakes to retrieve the gem from the chest." << endl << endl;
				} //close 2nd else if
				else
				{ //open else
					resolution = 3;
					cout << "Without using a torch it takes three hours and much dangerous work using" << endl
					<< "sticks to move the snakes individually, but you manage to clear away enough " << endl
					<< "to retrieve the gem from the chest." << endl << endl;
				} //close else
				break;
			} //close case 2
			case 3:
			{ //open case 3
				if (vectIn[1] == "torch")
				{ //open if
					cout << "Using your torch you scare the snakes away in no time. You manage to" << endl
					<< "retrieve the gem from the chest." << endl << endl;
				} //close 3rd if
				else if (vectIn[1] == "shovel")
				{ //open else if
					resolution = 1;
					cout << "Using a shovel is better than just your hands, but not as good as" << endl
					<< "a torch.  It takes one hour and much hard work, but you manage to" << endl
					<< "clear away enough snakes to retrieve the gem from the chest." << endl << endl;
				} //close else if
				else if (vectIn[0] == "machete")
				{ //open 2nd else if
					resolution = 1;
					cout << "Using a machete is better than just your hands, but not as good as" << endl
					<< "a torch.  It takes one hour and much hard work, but you manage to" << endl
					<< "clear away enough snakes to retrieve the gem from the chest." << endl << endl;
				} //close 2nd else if
				else
				{ //open else
					resolution = 3;
					cout << "Without using a torch it takes three hours and much dangerous work using" << endl
					<< "sticks to move the snakes individually, but you manage to clear away enough " << endl
					<< "to retrieve the gem from the chest." << endl << endl;
				} //close else
				break;
			} //close case 3
		} //close switch
	} //close 4th else if
	else if(obsTypeIn == "swept away")
	{ //open 5th else if
		switch(dangerChoice)
		{ //open switch
			case 1:
			{ //open case 1
				resolution = 3;
				cout << "Without a raft, the current overpowers you as you swim and pulls you" << endl
				<< "far off course. It takes three hours and much difficult swimming to reach" << endl
				<< "the island, find the chest and retrieve the gem, then return to the bank." << endl << endl;
				break;
			} //close case 1
			case 2:
			{ //open case 2
				if (vectIn[0] == "rope")
				{ //open if
					cout << "Using your rope to construct a crude raft with branches lying around," << endl
					<< "you navigate easily to the island and find the chest in no time. You" << endl
					<< "manage to retrieve the gem from the chest." << endl << endl;
				} //close if
				else
				{ //open else
					resolution = 3;
					cout << "Without a raft, the current overpowers you as you swim and pulls you" << endl
					<< "far off course. It takes three hours and much difficult swimming to reach" << endl
					<< "the island, find the chest and retrieve the gem, then return to the bank." << endl << endl;
				} //close else
				break;
			} //close case 2
			case 3:
			{ //open case 3
				if (vectIn[1] == "rope")
				{ //open 3rd if
					cout << "Using your rope to construct a crude raft with branches lying around," << endl
					<< "you navigate easily to the island and find the chest in no time. You" << endl
					<< "manage to retrieve the gem from the chest." << endl << endl;
				} //close 3rd if
				else
				{ //open else
					resolution = 3;
					cout << "Without a raft, the current overpowers you as you swim and pulls you" << endl
					<< "far off course. It takes three hours and much difficult swimming to reach" << endl
					<< "the island, find the chest and retrieve the gem, then return to the bank." << endl << endl;
				} //close else
				break;
			} //close case 3
		} //close switch
	} //close 5th else if	
	
	return resolution;
} //close ResolveTreas function


/*****************************************************************************
**EncounterTerr function:
**Initiate location obstacle encounter for Terrain locations. Call Menu to 
**get and then return the user's choice in how to react to the encounter.
*****************************************************************************/
int Danger::encounterTerr(string obsTypeIn, Menu gameMenu, vector<string> vectIn, int gemNum)
{ //open EncounterTerr function
	int dangerChoice = 0;
	cout << endl;
	
	if(obsTypeIn == "quicksand")
	{ //open if
		cout << "Walking through the open wetlands, you unknowingly step onto a patch of quicksand!" << endl << endl;
		dangerChoice = gameMenu.encounterDanger(obsTypeIn, vectIn, gemNum);
	} //close if
	else if(obsTypeIn == "wild boar")
	{ //open else if
		cout << "Walking through the brush, you startle a large wild boar." << endl << endl;
		dangerChoice = gameMenu.encounterDanger(obsTypeIn, vectIn, gemNum);
	} //close else if
	else if(obsTypeIn == "sunstroke")
	{ //open else if
		cout << "Walking through the open land after your exhausting ordeal, you feel the sun and" << endl
		<< "heat beating down on you, leading to sunstroke." << endl << endl;
		dangerChoice = gameMenu.encounterDanger(obsTypeIn, vectIn, gemNum);
	} //close else if
	else if(obsTypeIn == "cave")
	{ //open else if
		cout << "Walking along the mountain slope, you reach a steep impasse with only a cave" << endl
		<< "opening to pass to the other side." << endl << endl;
		dangerChoice = gameMenu.encounterDanger(obsTypeIn, vectIn, gemNum);
	} //close else if
	else if(obsTypeIn == "rockslide")
	{ //open else if
		cout << "Walking along the mountain slope, you hear a loud rumble and a rush of rocks crash" << endl
		<< "across the path ahead of you. Your way is now blocked by the remains of the rockslide." << endl << endl;
		dangerChoice = gameMenu.encounterDanger(obsTypeIn, vectIn, gemNum);
	} //close else if
	else if(obsTypeIn == "crevice")
	{ //open else if
		cout << "Walking along the mountain slope, your path ends in a narrow but extremely deep crevice." << endl << endl;
		dangerChoice = gameMenu.encounterDanger(obsTypeIn, vectIn, gemNum);
	} //close else if
	else if(obsTypeIn == "overgrowth")
	{ //open else if
		cout << "Walking through the dense jungle, the vegetation grows thicker until all around" << endl
		<< "you it is too dense and overgrown to continue walking normally." << endl << endl;
		dangerChoice = gameMenu.encounterDanger(obsTypeIn, vectIn, gemNum);
	} //close else if
	else if(obsTypeIn == "pit")
	{ //open else if
		cout << "Walking through the dense jungle, the vegetation obscures your view and you stumble" << endl
		<< "across the edge of a deep pit." << endl << endl;
		dangerChoice = gameMenu.encounterDanger(obsTypeIn, vectIn, gemNum);
	} //close else if
	else if(obsTypeIn == "spider")
	{ //open else if
		cout << "Walking through the dense jungle, you keep a careful out for snakes and wild boar." << endl
		<< "Unfortunately you don't see the large spider above as it drops down onto you." << endl << endl;
		dangerChoice = gameMenu.encounterDanger(obsTypeIn, vectIn, gemNum);
	} //close else if
	else if(obsTypeIn == "current")
	{ //open else if
		cout << "Attempting to cross the river, you notice the current along this section is extremely strong." << endl << endl;
		dangerChoice = gameMenu.encounterDanger(obsTypeIn, vectIn, gemNum);
	} //close else if
	else if(obsTypeIn == "crocodile")
	{ //open else if
		cout << "Attempting to cross the river, you notice a pair of eyes on the surface of the water," << endl
		<< "watching you." << endl << endl;
		dangerChoice = gameMenu.encounterDanger(obsTypeIn, vectIn, gemNum);
	} //close else if

	return dangerChoice;
} //close EncounterTerr function


/*****************************************************************************
**resolveTerr function:
**Complete location obstacle encounter for Terrain locations with value 
**returned by Encounter function above. Compare obstacle type to inventory, 
**and return a value representing how much time is spent on the encounter.
**Some items negate the encounter's impact, some reduce it, and some don't
**help at all.
*****************************************************************************/
int Danger::resolveTerr(int dangerChoice, string obsTypeIn, vector<string> vectIn, bool &defeat)
{ //open ResolveTerr function
	int resolution = 0;
	cout << endl;
	
	if(obsTypeIn == "quicksand")
	{ //open if
		switch(dangerChoice)
		{ //open switch
			case 1:
			{ //open case 1
				resolution = 2;
				cout << "Without using a rope or shovel it takes two hours and much painful work, but" << endl
				<< "you manage to drag yourself clear. You won't be caught in that again." << endl << endl;
				break;
			} //close case 1
			case 2:
			{ //open case 2
				if (vectIn[0] == "shovel")
				{ //open 2nd if
					cout << "Thinking quickly, you use your shovel to anchor yourself to solid ground." << endl
					<< "You manage to get clear in no time at all. You won't be caught in that again." << endl << endl;
				} //close 2nd if
				else if (vectIn[0] == "rope")
				{ //open else if
					cout << "Thinking quickly, you use your rope to anchor yourself to solid ground." << endl
					<< "You manage to get clear in no time at all. You won't be caught in that again." << endl << endl;
				} //close else if
				else if (vectIn[0] == "pickax")
				{ //open else if
					cout << "Thinking quickly, you use your pickax to anchor yourself to solid ground." << endl
					<< "You manage to get clear in no time at all. You won't be caught in that again." << endl << endl;
				} //close else if
				else
				{ //open else
					resolution = 2;
					cout << "Without using a rope or shovel it takes two hours and much painful work, but" << endl
					<< "you manage to drag yourself clear. You won't be caught in that again." << endl << endl;
				} //close else
				break;
			} //close case 2
			case 3:
			{ //open case 3
				if (vectIn[1] == "shovel")
				{ //open 2nd if
					cout << "Thinking quickly, you use your shovel to anchor yourself to solid ground." << endl
					<< "You manage to get clear in no time at all. You won't be caught in that again." << endl << endl;
				} //close 2nd if
				else if (vectIn[1] == "rope")
				{ //open else if
					cout << "Thinking quickly, you use your rope to anchor yourself to solid ground." << endl
					<< "You manage to get clear in no time at all. You won't be caught in that again." << endl << endl;
				} //close else if
				else if (vectIn[1] == "pickax")
				{ //open else if
					cout << "Thinking quickly, you use your pickax to anchor yourself to solid ground." << endl
					<< "You manage to get clear in no time at all. You won't be caught in that again." << endl << endl;
				} //close else if
				else
				{ //open else
					resolution = 2;
					cout << "Without using a rope or shovel it takes two hours and much painful work, but" << endl
					<< "you manage to drag yourself clear. You won't be caught in that again." << endl << endl;
				} //close else
				break;
			} //close case 3
		} //close switch
	} //close if
	else if(obsTypeIn == "wild boar")
	{ //open else if
		switch(dangerChoice)
		{ //open switch
			case 1:
			{ //open case 1
				resolution = 2;
				cout << "Without using a torch or weapon you wait for the dangerous animal to leave" << endl
				<< "before continuing. The tense, dangerous wait takes two hours, but you doubt" << endl
				<< "you'll see that boar here again." << endl << endl;
				break;
			} //close case 1
			case 2:
			{ //open case 2
				if (vectIn[0] == "torch")
				{ //open if
					cout << "Using your torch as a threatening weapon, you scare away the animal in" << endl
					<< "no time. You doubt you'll see that boar here again." << endl << endl;
				} //close if
				else if (vectIn[0] == "shovel")
				{ //open else if
					cout << "Using your shovel as a threatening weapon, you scare away the animal in" << endl
					<< "no time. You doubt you'll see that boar here again." << endl << endl;
				} //close else if
				else if (vectIn[0] == "machete")
				{ //open else if
					cout << "Using your machete as a threatening weapon, you scare away the animal in" << endl
					<< "no time. You doubt you'll see that boar here again." << endl << endl;
				} //close else if
				else if (vectIn[0] == "pickax")
				{ //open else if
					cout << "Using your pickax as a threatening weapon, you scare away the animal in" << endl
					<< "no time. You doubt you'll see that boar here again." << endl << endl;
				} //close else if
				else
				{ //open else
					resolution = 2;
					cout << "Without using a torch or weapon you wait for the dangerous animal to leave" << endl
					<< "before continuing. The tense, dangerous wait takes two hours, but you doubt" << endl
					<< "you'll see that boar here again." << endl << endl;
				} //close else
				break;
			} //close case 2
			case 3:
			{ //open case 3
				if (vectIn[1] == "torch")
				{ //open if
					cout << "Using your torch as a threatening weapon, you scare away the animal in" << endl
					<< "no time. You doubt you'll see that boar here again." << endl << endl;
				} //close if
				else if (vectIn[1] == "shovel")
				{ //open else if
					cout << "Using your shovel as a threatening weapon, you scare away the animal in" << endl
					<< "no time. You doubt you'll see that boar here again." << endl << endl;
				} //close else if
				else if (vectIn[1] == "machete")
				{ //open else if
					cout << "Using your machete as a threatening weapon, you scare away the animal in" << endl
					<< "no time. You doubt you'll see that boar here again." << endl << endl;
				} //close else if
				else if (vectIn[1] == "pickax")
				{ //open else if
					cout << "Using your pickax as a threatening weapon, you scare away the animal in" << endl
					<< "no time. You doubt you'll see that boar here again." << endl << endl;
				} //close else if
				else
				{ //open else
					resolution = 2;
					cout << "Without using a torch or weapon you wait for the dangerous animal to leave" << endl
					<< "before continuing. The tense, dangerous wait takes two hours, but you doubt" << endl
					<< "you'll see that boar here again." << endl << endl;
				} //close else
				break;
			} //close case 3
		} //close switch
	} //close else if
	else if(obsTypeIn == "sunstroke")
	{ //open 2nd else if
		switch(dangerChoice)
		{ //open switch
			case 1:
			{ //open case 1
				resolution = 2;
				cout << "Without shade from a hat, you succumb to the heat. It takes two hours of rest" << endl
				<< "before you feel recovered enough to travel again." << endl << endl;
				break;
			} //close case 1
			case 2:
			{ //open case 2
				if (vectIn[0] == "hat")
				{ //open if
					cout << "With your stylish hat providing shade, you are able to travel in the sun losing" << endl
					<< "no time. Knowing the signs to watch for, you won't be overwhelmed here in the future." << endl << endl;
				} //close if
				else
				{ //open else
					resolution = 2;
					cout << "Without shade from a hat, you succumb to the heat. It takes two hours of rest" << endl
					<< "before you feel recovered enough to travel again. Knowing the signs to watch for," << endl
					<< "you won't be overwhelmed here in the future." << endl << endl;
				} //close else
				break;
			} //close case 2
			case 3:
			{ //open case 3
				if (vectIn[1] == "hat")
				{ //open if
					cout << "With your stylish hat providing shade, you are able to travel in the sun losing" << endl
					<< "no time. Knowing the signs to watch for, you won't be overwhelmed here in the future." << endl << endl;
				} //close if
				else
				{ //open else
					resolution = 2;
					cout << "Without shade from a hat, you succumb to the heat. It takes two hours of rest" << endl
					<< "before you feel recovered enough to travel again. Knowing the signs to watch for," << endl
					<< "you won't be overwhelmed here in the future." << endl << endl;
				} //close else
				break;
			} //close case 3
		} //close switch
	} //close 2nd else if
	else if(obsTypeIn == "cave")
	{ //open 3rd else if
		switch(dangerChoice)
		{ //open switch
			case 1:
			{ //open case 1
				resolution = 2;
				cout << "Without using a torch to light your way it takes two hours and much painful" << endl
				<< "searching, but you manage to make your way through the cave and out the other side." << endl
				<< "You are now familiar enough with the passage that you won't be stuck here again." << endl << endl;
				break;
			} //close case 1
			case 2:
			{ //open case 2
				if (vectIn[0] == "torch")
				{ //open if
					cout << "Using your torch to light your way, you navigate the cave passage in no time." << endl
					<< "You are now familiar enough with the passage that you won't be stuck here again." << endl << endl;
				} //close if
				else
				{ //open else
					resolution = 2;
					cout << "Without using a torch to light your way it takes two hours and much painful" << endl
					<< "searching, but you manage to make your way through the cave and out the other side." << endl
					<< "You are now familiar enough with the passage that you won't be stuck here again." << endl << endl;
				} //close else
				break;
			} //close case 2
			case 3:
			{ //open case 3
				if (vectIn[1] == "torch")
				{ //open if
					cout << "Using your torch to light your way, you navigate the cave passage in no time." << endl
					<< "You are now familiar enough with the passage that you won't be stuck here again." << endl << endl;
				} //close if
				else
				{ //open else
					resolution = 2;
					cout << "Without using a torch to light your way it takes two hours and much painful" << endl
					<< "searching, but you manage to make your way through the cave and out the other side." << endl
					<< "You are now familiar enough with the passage that you won't be stuck here again." << endl << endl;
				} //close else
				break;
			} //close case 3
		} //close switch
	} //close 3rd else if
	else if(obsTypeIn == "rockslide")
	{ //open 4th else if
		switch(dangerChoice)
		{ //open switch
			case 1:
			{ //open case 1
				resolution = 2;
				cout << "Without using a pickax it takes two hours and much difficult work to clear" << endl
				<< "a path through the rocks. The clear path should prevent you from being stuck" << endl
				<< "here again in the future." << endl << endl;
				break;
			} //close case 1
			case 2:
			{ //open case 2
				if (vectIn[0] == "pickax")
				{ //open if
					cout << "Using your pickax you clear a path through the rocks in no time." << endl
					<< "The clear path should prevent you from being stuck here again in the future." << endl << endl;
				} //close if
				else if (vectIn[0] == "shovel")
				{ //open else if
					resolution = 1;
					cout << "Using a shovel is better than just your hands, but not as good as a pickax." << endl
					<< "It takes one hour and much hard work, but you manage to clear a path." << endl
					<< "The clear path should prevent you from being stuck here again in the future." << endl << endl;
				} //close else if
				else
				{ //open else
					resolution = 2;
					cout << "Without using a pickax it takes two hours and much difficult work to clear" << endl
					<< "a path through the rocks. The clear path should prevent you from being stuck" << endl
					<< "here again in the future." << endl << endl;
				} //close else
				break;
			} //close case 2
			case 3:
			{ //open case 3
				if (vectIn[0] == "pickax")
				{ //open if
					cout << "Using your pickax you clear a path through the rocks in no time." << endl
					<< "The clear path should prevent you from being stuck here again in the future." << endl << endl;
				} //close if
				else if (vectIn[0] == "shovel")
				{ //open else if
					resolution = 1;
					cout << "Using a shovel is better than just your hands, but not as good as a pickax." << endl
					<< "It takes one hour and much hard work, but you manage to clear a path." << endl
					<< "The clear path should prevent you from being stuck here again in the future." << endl << endl;
				} //close else if
				else
				{ //open else
					resolution = 2;
					cout << "Without using a pickax it takes two hours and much difficult work to clear" << endl
					<< "a path through the rocks. The clear path should prevent you from being stuck" << endl
					<< "here again in the future." << endl << endl;
				} //close else
				break;
			} //close case 3
		} //close switch
	} //close 4th else if
	else if(obsTypeIn == "crevice")
	{ //open 5th else if
		switch(dangerChoice)
		{ //open switch
			case 1:
			{ //open case 1
				resolution = 2;
				cout << "Without a rope, you aren't able to bridge the gap. It takes two hours to" << endl
				<< "find a way around the crevice and continue on your way. Knowing how to avoid" << endl
				<< "the crevice now, you won't get stuck here again." << endl << endl;
				break;
			} //close case 1
			case 2:
			{ //open case 2
				if (vectIn[0] == "rope")
				{ //open if
					cout << "Using your rope to construct a crude bridge with branches lying around," << endl
					<< "you cross to the other side in no time. With a way across, you won't get" << endl
					<< "stuck here again." << endl << endl;
				} //close if
				else
				{ //open else
					resolution = 2;
					cout << "Without a rope, you aren't able to bridge the gap. It takes two hours to" << endl
					<< "find a way around the crevice and continue on your way. Knowing how to avoid" << endl
					<< "the crevice now, you won't get stuck here again." << endl << endl;
				} //close else
				break;
			} //close case 2
			case 3:
			{ //open case 3
				if (vectIn[1] == "rope")
				{ //open if
					cout << "Using your rope to construct a crude bridge with branches lying around," << endl
					<< "you cross to the other side in no time. With a way across, you won't get" << endl
					<< "stuck here again." << endl << endl;
				} //close if
				else
				{ //open else
					resolution = 2;
					cout << "Without a rope, you aren't able to bridge the gap. It takes two hours to" << endl
					<< "find a way around the crevice and continue on your way. Knowing how to avoid" << endl
					<< "the crevice now, you won't get stuck here again." << endl << endl;
				} //close else
				break;
			} //close case 3
		} //close switch
	} //close 5th else if
	else if(obsTypeIn == "overgrowth")
	{ //open 5th else if
		switch(dangerChoice)
		{ //open switch
			case 1:
			{ //open case 1
				resolution = 2;
				cout << "Without a machete, the dense overgrowth prevents forward progress. You" << endl
				<< "spend two difficult hours backtracking and finding a new path onward." << endl
				<< "Knowing how to travel around the overgrowth, you won't get stuck here again." << endl << endl;
				break;
			} //close case 1
			case 2:
			{ //open case 2
				if (vectIn[0] == "machete")
				{ //open if
					cout << "Using your machete you clear a path through the plants in no time." << endl
					<< "The clear path should prevent you from being stuck here again in the future." << endl << endl;
				} //close if
				else if (vectIn[0] == "shovel")
				{ //open else if
					resolution = 1;
					cout << "Using a shovel is better than just your hands, but not as good as a machete." << endl
					<< "It takes one hour and much hard work, but you manage to clear a path." << endl
					<< "The clear path should prevent you from being stuck here again in the future." << endl << endl;
				} //close else if
				else
				{ //open else
					resolution = 2;
					cout << "Without a machete, the dense overgrowth prevents forward progress. You" << endl
					<< "spend two difficult hours backtracking and finding a new path onward." << endl
					<< "Knowing how to travel around the overgrowth, you won't get stuck here again." << endl << endl;
				} //close else
				break;
			} //close case 2
			case 3:
			{ //open case 3
				if (vectIn[1] == "machete")
				{ //open if
					cout << "Using your machete you clear a path through the plants in no time." << endl
					<< "The clear path should prevent you from being stuck here again in the future." << endl << endl;
				} //close if
				else if (vectIn[1] == "shovel")
				{ //open else if
					resolution = 1;
					cout << "Using a shovel is better than just your hands, but not as good as a machete." << endl
					<< "It takes one hour and much hard work, but you manage to clear a path." << endl
					<< "The clear path should prevent you from being stuck here again in the future." << endl << endl;
				} //close else if
				else
				{ //open else
					resolution = 2;
					cout << "Without a machete, the dense overgrowth prevents forward progress. You" << endl
					<< "spend two difficult hours backtracking and finding a new path onward." << endl
					<< "Knowing how to travel around the overgrowth, you won't get stuck here again." << endl << endl;
				} //close else
				break;
			} //close case 3
		} //close switch
	} //close 5th else if
	else if(obsTypeIn == "pit")
	{ //open 5th else if
		switch(dangerChoice)
		{ //open switch
			case 1:
			{ //open case 1
				resolution = 2;
				cout << "Without a rope or shovel, you fall into the pit with no easy way out." << endl
				<< "It takes two hours and much difficult climbing up the soft earth to reach" << endl
				<< "the top and continue on your way. You won't be caught in that again." << endl << endl;
				break;
			} //close case 1
			case 2:
			{ //open case 2
				if (vectIn[0] == "shovel")
				{ //open 2nd if
					cout << "Thinking quickly, you use your shovel to anchor yourself to solid ground." << endl
					<< "You manage to get clear in no time at all. You won't be caught in that again." << endl << endl;
				} //close 2nd if
				else if (vectIn[0] == "rope")
				{ //open else if
					cout << "You tumble over the edge into the pit. Thinking quickly, you loop your rope" << endl
					<< "around a sturdy branch and climb free. You manage to get clear in no time at all." << endl
					<< "You won't be caught in that again." << endl << endl;
				} //close else if
				else if (vectIn[0] == "pickax")
				{ //open else if
					cout << "Thinking quickly, you use your pickax to anchor yourself to solid ground." << endl
					<< "You manage to get clear in no time at all. You won't be caught in that again." << endl << endl;
				} //close else if
				else
				{ //open else
					resolution = 2;
					cout << "Without a rope or shovel, you fall into the pit with no easy way out." << endl
					<< "It takes two hours and much difficult climbing up the soft earth to reach" << endl
					<< "the top and continue on your way. You won't be caught in that again." << endl << endl;
				} //close else
				break;
			} //close case 2
			case 3:
			{ //open case 3
				if (vectIn[1] == "shovel")
				{ //open 2nd if
					cout << "Thinking quickly, you use your shovel to anchor yourself to solid ground." << endl
					<< "You manage to get clear in no time at all. You won't be caught in that again." << endl << endl;
				} //close 2nd if
				else if (vectIn[1] == "rope")
				{ //open else if
					cout << "You tumble over the edge into the pit. Thinking quickly, you loop your rope" << endl
					<< "around a sturdy branch and climb free. You manage to get clear in no time at all." << endl
					<< "You won't be caught in that again." << endl << endl;
				} //close else if
				else if (vectIn[1] == "pickax")
				{ //open else if
					cout << "Thinking quickly, you use your pickax to anchor yourself to solid ground." << endl
					<< "You manage to get clear in no time at all. You won't be caught in that again." << endl << endl;
				} //close else if
				else
				{ //open else
					resolution = 2;
					cout << "Without a rope or shovel, you fall into the pit with no easy way out." << endl
					<< "It takes two hours and much difficult climbing up the soft earth to reach" << endl
					<< "the top and continue on your way. You won't be caught in that again." << endl << endl;
				} //close else
				break;
			} //close case 3
		} //close switch
	} //close 5th else if
	else if(obsTypeIn == "spider")
	{ //open 5th else if
		switch(dangerChoice)
		{ //open switch
			case 1:
			{ //open case 1
				resolution = 1;
				cout << "Without a hat, the spider lands on your shoulders, scaring you. You quickly" << endl
				<< "brush it off before it bites you. Looking up above your chosen path, you see" << endl
				<< "many more spiders in the branches. Deciding to backtrack and find a safer path," << endl
				<< "you lose an hour. Knowing how to avoid that nest of spiders, you won't run" << endl
				<< "into them again." << endl << endl;
				break;
			} //close case 1
			case 2:
			{ //open case 2
				if (vectIn[0] == "hat")
				{ //open if
					cout << "The large spider drops onto your stylish hat, which you quickly pull" << endl
					<< "off, shaking the spider clear. Looking up above your chosen path, you see" << endl
					<< "many more spiders in the branches. Knowing your hat will keep you safe, you" << endl
					<< "travel through in no time. These spiders will be no threat to you anymore." << endl << endl;
				} //close if
				else
				{ //open else
					resolution = 1;
					cout << "Without a hat, the spider lands on your shoulders, scaring you. You quickly" << endl
					<< "brush it off before it bites you. Looking up above your chosen path, you see" << endl
					<< "many more spiders in the branches. Deciding to backtrack and find a safer path," << endl
					<< "you lose an hour. Knowing how to avoid that nest of spiders, you won't run" << endl
					<< "into them again." << endl << endl;
				} //close else
				break;
			} //close case 2
			case 3:
			{ //open case 3
				if (vectIn[1] == "hat")
				{ //open if
					cout << "The large spider drops onto your stylish hat, which you quickly pull" << endl
					<< "off, shaking the spider clear. Looking up above your chosen path, you see" << endl
					<< "many more spiders in the branches. Knowing your hat will keep you safe, you" << endl
					<< "travel through in no time. These spiders will be no threat to you anymore." << endl << endl;
				} //close if
				else
				{ //open else
					resolution = 1;
					cout << "Without a hat, the spider lands on your shoulders, scaring you. You quickly" << endl
					<< "brush it off before it bites you. Looking up above your chosen path, you see" << endl
					<< "many more spiders in the branches. Deciding to backtrack and find a safer path," << endl
					<< "you lose an hour. Knowing how to avoid that nest of spiders, you won't run" << endl
					<< "into them again." << endl << endl;
				} //close else
				break;
			} //close case 3
		} //close switch
	} //close 5th else if
	else if(obsTypeIn == "current")
	{ //open 5th else if
		switch(dangerChoice)
		{ //open switch
			case 1:
			{ //open case 1
				resolution = 2;
				cout << "Without a raft, the current overpowers you as you swim. You drift far" << endl
				<< "off course and struggle to reach the far bank of the river. It takes two" << endl
				<< "hours to complete the swim, then rest and recover enough to move on." << endl << endl;
				break;
			} //close case 1
			case 2:
			{ //open case 2
				if (vectIn[0] == "rope")
				{ //open if
					cout << "Using your rope to construct a crude raft with branches lying around," << endl
					<< "you navigate easily to the far side of the river in no time. With a way" << endl
					<< "across, you won't have trouble crossing again." << endl << endl;
				} //close if
				else
				{ //open else
					resolution = 2;
					cout << "Without a raft, the current overpowers you as you swim. You drift far" << endl
					<< "off course and struggle to reach the far bank of the river. It takes two" << endl
					<< "hours to complete the swim, then rest and recover enough to move on." << endl << endl;
				} //close else
				break;
			} //close case 2
			case 3:
			{ //open case 3
				if (vectIn[0] == "rope")
				{ //open if
					cout << "Using your rope to construct a crude raft with branches lying around," << endl
					<< "you navigate easily to the far side of the river in no time. With a way" << endl
					<< "across, you won't have trouble crossing again." << endl << endl;
				} //close if
				else
				{ //open else
					resolution = 2;
					cout << "Without a raft, the current overpowers you as you swim. You drift far" << endl
					<< "off course and struggle to reach the far bank of the river. It takes two" << endl
					<< "hours to complete the swim, then rest and recover enough to move on." << endl << endl;
				} //close else
				break;
			} //close case 3
		} //close switch
	} //close 5th else if
	else if(obsTypeIn == "crocodile")
	{ //open 5th else if
		switch(dangerChoice)
		{ //open switch
			case 1:
			{ //open case 1
				resolution = 2;
				cout << "Without a torch or long tool for a weapon, you can't chance crossing here" << endl
				<< "with a crocodile around. It takes two hours to find another section of river" << endl
				<< "safe enough to cross and make it to the other side. Knowing what to look for" << endl
				<< "now, you shouldn't have trouble crossing in the future." << endl << endl;
				break;
			} //close case 1
			case 2:
			{ //open case 2
				if (vectIn[0] == "rope")
				{ //open if
					resolution = 1;
					cout << "Using your rope to construct a crude raft with branches lying around," << endl
					<< "you cross easily to the far side of the river, after searching for an hour" << endl
					<< "to find a safe place to cross away from hungry crocodiles. With a way" << endl
					<< "across, you won't have trouble crossing again." << endl << endl;
				} //close if
				if (vectIn[0] == "torch")
				{ //open if
					cout << "Using your torch as a threatening weapon, you scare away the animal in" << endl
					<< "no time. You doubt you'll see that crocodile here again." << endl << endl;
				} //close if
				else if (vectIn[0] == "shovel")
				{ //open else if
					cout << "Using your shovel as a threatening weapon, you scare away the animal in" << endl
					<< "no time. You doubt you'll see that crocodile here again." << endl << endl;
				} //close else if
				else if (vectIn[0] == "pickax")
				{ //open else if
					cout << "Using your pickax as a threatening weapon, you scare away the animal in" << endl
					<< "no time. You doubt you'll see that crocodile here again." << endl << endl;
				} //close else if
				else
				{ //open else
					resolution = 2;
					cout << "Without a torch or long tool for a weapon, you can't chance crossing here" << endl
					<< "with a crocodile around. It takes two hours to find another section of river" << endl
					<< "safe enough to cross and make it to the other side. Knowing what to look for" << endl
					<< "now, you shouldn't have trouble crossing in the future." << endl << endl;
				} //close else
				break;
			} //close case 2
			case 3:
			{ //open case 3
				if (vectIn[1] == "rope")
				{ //open if
					resolution = 1;
					cout << "Using your rope to construct a crude raft with branches lying around," << endl
					<< "you cross easily to the far side of the river, after searching for an hour" << endl
					<< "to find a safe place to cross away from hungry crocodiles. With a way" << endl
					<< "across, you won't have trouble crossing again." << endl << endl;
				} //close if
				if (vectIn[1] == "torch")
				{ //open if
					cout << "Using your torch as a threatening weapon, you scare away the animal in" << endl
					<< "no time. You doubt you'll see that crocodile here again." << endl << endl;
				} //close if
				else if (vectIn[1] == "shovel")
				{ //open else if
					cout << "Using your shovel as a threatening weapon, you scare away the animal in" << endl
					<< "no time. You doubt you'll see that crocodile here again." << endl << endl;
				} //close else if
				else if (vectIn[1] == "pickax")
				{ //open else if
					cout << "Using your pickax as a threatening weapon, you scare away the animal in" << endl
					<< "no time. You doubt you'll see that crocodile here again." << endl << endl;
				} //close else if
				else
				{ //open else
					resolution = 2;
					cout << "Without a torch or long tool for a weapon, you can't chance crossing here" << endl
					<< "with a crocodile around. It takes two hours to find another section of river" << endl
					<< "safe enough to cross and make it to the other side. Knowing what to look for" << endl
					<< "now, you shouldn't have trouble crossing in the future." << endl << endl;
				} //close else
				break;
			} //close case 3
		} //close switch
	} //close 5th else if
	
	return resolution;
} //close ResolveTerr function