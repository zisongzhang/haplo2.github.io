/******************************************************************** 
** Author: Tyler Williams
** Date: 6-12-18
** Description: This program is a pirate themed island treasure hunt.
** The player moves around a board of different terrain, finding
** treasures and facing dangerous challenges. If they manage to find
** enough treasure before other treasure hunters, they win a fortune.
*********************************************************************/
#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>

#include "menu.hpp"
#include "game.hpp"

using std::cin;
using std::cout;
using std::endl;
using std::string;

void startMsg();

int main()
{ //open main
	Menu gameMenu;
	Game playGame;
	
	srand(time(NULL));
	
	int userChoice = gameMenu.playChoice();
	while (userChoice == 1)
	{ //open while
		gameMenu.startMsg();
		playGame.control(gameMenu);
		userChoice = gameMenu.playChoice();
	} //close while
	return 0;
} //close main

