/******************************************************************** 
** Author: Tyler Williams
** Date: 6-12-18
** Description: This Board class has functions to construct a Board 
** object, print the Board, set individual spaces to new objects,
** pseudorandomly replace certain positions with new Treasure objects,
** & pseudorandomly replace certain Treasure objects with Terrain objects.
*********************************************************************/
#ifndef BOARD_HPP
#define BOARD_HPP

#include <iostream>
#include <string>
#include <cstdlib>
#include <vector>

#include "space.hpp"
#include "terrain.hpp"
#include "treasure.hpp"

using std::cin;
using std::cout;
using std::endl;
using std::string;
using std::vector;

class Board
{
private:
	vector<int> gemVect;
public:
	Board(Space*** &, int, int, int, int);
	int showGems(Space*** &, int, int, int, int);
	void printBoard(Space***, int, int, int, int);
	void timerFindGems(Space*** &, int, int, int, int);
	void setNATerrain(Space*** &, int, int);
	void setWTerrain(Space*** &, int, int);
	void setMTerrain(Space*** &, int, int);
	void setJTerrain(Space*** &, int, int);
	void setRTerrain(Space*** &, int, int);
	void setBigTreasure(Space*** &, int, int);
	void setSmallTreasure(Space*** &, int, int);
	
};
#include "board.cpp"
#endif