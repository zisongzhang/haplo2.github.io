/********************************************************************** 
** Author: Tyler Williams
** Date: 6-12-18
** Description: This Menu class has functions to print text to the screen
** and sometimes to get user input for use by the calling function.
*********************************************************************/
#include <iostream>
#include <string>
#include <vector>

#include "menu.hpp"

using std::cin;
using std::cout;
using std::endl;
using std::string;
using std::vector;


/*****************************************************************************
**playChoice function:
**Get user input for playing the game or quitting
*****************************************************************************/
int Menu::playChoice()
{ //open playChoice function
	int choice = 0;
	
	cout << endl << "Welcome to Island O' Treasure." << endl
	<< "Would you like to join the treasure hunt, Captain?" << endl;
	cout << "1: Play" << endl;
	cout << "2: Exit" << endl;
	cin >> choice;
	
	while (!(choice == 1 || choice == 2))
	{ //open input validation while loop
		cin.clear();
		cin.ignore(1000, '\n');
		cout << "That is not a valid selection. Please enter 1 or 2." << endl;
		cout << endl << "1: Play" << endl;
		cout << "2: Exit" << endl;
		cin >> choice;
		choice = ((int) choice/1);
	} //close input validation while loop
	cin.ignore(1000, '\n');
	
	cout << endl;
	
	return choice;
} //close playChoice function


/*****************************************************************************
**startMsg function:
**Display beginning of game text
*****************************************************************************/
void Menu::startMsg()
{ //open startMsg function
	int helpChoice = 0;
	
	cout << endl << "Walking the streets of the island harbor town Portly, you step out of the" << endl <<
	"nightly rain into the tavern called The Drowned Rat. Scanning the room, you see" << endl
	<< "a wild-eyed old man sitting alone in a corner and join him at his table." << endl << endl;
	
	cout << "\"Welcome Cap'n. Are ye here like all the rest, in search of the famed treasure " << endl <<
	"of Captain One-Eyed Jack?\"" << endl << endl;
	
	cout << "When you nod, he continues." << endl << endl << "\"Ye've come to ol' Still-Has-Both-Eyes Jack" <<
	" looking for a map from his last" << endl << "surviving crewman, eh? Lucky fer us both, I have one.\"" << endl;
	
	cout << endl << "\"Several other captains have been asking around town, but I know those scurvy dogs" 
	<< endl << "and wouldn't trust a one of them not to stab me in the back.\"" << endl << endl;
	
	cout << "\"I'll make ye a deal, newcomer. Take me to the island with ye, and we'll split " << endl
	<< "the treasure even. Of course, I'm the only one what knows which island it's on " << endl 
	<< "so you don't have much choice, do ye?\"" << endl << endl;
	
	cout << "After you nod and shake on the deal, Still-Has-Both-Eyes Jack says, " << endl;
	cout << "\"Good. Now we best get sailing afore one of these other cap'ns tracks me down.\"" << endl;
	
	cout << endl << "Press Enter to continue" << endl;
	cin.get();
	cout << endl << endl;

	cout << "As you leave Portly town, Jack gives you direction to Island O' Treasure." << endl
	<< "On the way, he gives you the map and offers some advice about the island." << endl;
	cout << "Would you like to hear this advice now?" << endl;
	cout << "1: Yes" << endl << "2: No" << endl;
	cin >> helpChoice;
	
	while (!(helpChoice == 1 || helpChoice == 2))
	{ //open input validation while loop
		cin.clear();
		cin.ignore(1000, '\n');
		cout << "That is not a valid selection. Please enter 1 or 2." << endl;
		cout << endl << "1: Yes" << endl;
		cout << "2: No" << endl;
		cin >> helpChoice;
		helpChoice = ((int) helpChoice/1);
	} //close input validation while loop
	cin.ignore(1000, '\n');
	
	if (helpChoice == 1)
	{ //open if
		cout << endl << "\"This island be totally wild. Almost nobody even knows about it. The terrain is " << endl
		<< " untamed and difficult to travel. The rocky coast has few beaches safe for landing." << endl;
		cout << " There are steep, rocky mountains on the north side with a large river flowing south." << endl;
		cout << " The river splits the rest of the island between jungle and open brush." << endl;
		cout << " This island be full of wild animals, so keep yer wits about ye.\"" << endl << endl;
		
		cout << "\"If we're lucky, we'll be able to navigate around the coast in this rain tonight" << endl;
		cout << " and land on a small beach on the south side. From there it'd be a straight shot" << endl;
		cout << " through open ground to One-Eyed Jack's hidden treasure in the center of the island." << endl;
		cout << " The map be marked with an X to show ye where the riches be. Best make sure ye bring" << endl
		<< " enough equipment so we can handle any problems and recover the treasure quickly.\"" << endl;
		
		cout << endl << "Press Enter to continue" << endl;
		cin.get();
	} //close if

	cout << endl << endl << "As you attempt to navigate the uncivilized waters around the mysterious island" << endl;
	cout << "in the stormy night, you hear the terrifying sounds of your ship striking rocks." << endl;
	cout << "In the wind and rain, the stormy sea quickly smashes your ship to ruin. As you direct" << endl
	<< "your crew to try to escape safely, you are washed overboard. Lost in the darkness" << endl
	<< "of the night and water, you struggle to stay afloat. Eventually you wash up on a beach," << endl
	<< "exhausted and alone." << endl << endl;
	
	cout << "You look around just as dawn is breaking, the nightly storm passing away, and realize" << endl
	<< "you have nothing but your clothes, the compass you always keep strapped to your belt, and the map." << endl;

	cout << endl << "With no better option, you decide to make for the treasure site." << endl << endl;

	cout << "Press Enter to continue" << endl;
	cin.get();

	cout << "You can move around the map using 1-4 and pressing enter." << endl;
	cout << "		1: move Up " << endl;
	cout << "4: move Left		2: move Right" << endl;
	cout << "		3: move Down " << endl << endl;
	
	cout << "You will be able to gain items as you explore the island. You can only carry two" << endl
	<< "items at a time, in addition to your map and compass." << endl << endl;
	
	cout << "As you travel, you may encounter dangerous situations. You will control the game by typing" << endl 
	<< "a number that matches the option provided on the screen at any time and pressing enter." << endl;
	cout << "In each location, you will have the option to search for treasure or useful items." << endl;
	cout << "The items you carry may be able to aid you in these situations. Choose your inventory wisely." << endl << endl;

	cout << "When traveling, you can choose how quickly you move. Moving fast saves time but increases the" << endl <<
	"chances of encountering problems you might have avoided by being more careful. Moving slow is" << endl
	<< "safer but takes more time." << endl;
	
	cout << endl << "At any time you can access these Help instructions by pressing 8." << endl;
	cout << endl << "Press Enter to continue" << endl;
	cin.get();
	
	cout << endl;
} //close startMsg function


/*****************************************************************************
**printHelp function:
**Display help and controls text
*****************************************************************************/
void Menu::printHelp()
{ //open printHelp function
	cout << endl;
	cout << "You can move around the map using 1-4 and pressing enter." << endl;
	cout << "		1: move Up " << endl;
	cout << "4: move Left		2: move Right" << endl;
	cout << "		3: move Down " << endl << endl;
	
	cout << "You will be able to gain items as you explore the island. You can only carry two" << endl
	<< "items at a time, in addition to your map and compass." << endl << endl;
	
	cout << "As you travel, you may encounter dangerous situations. You will control the game by typing" << endl 
	<< "a number that matches the option provided on the screen at any time and pressing enter." << endl;
	cout << "In each location, you will have the option to search for treasure or useful items." << endl;
	cout << "The items you carry may be able to aid you in these situations. Choose your inventory wisely." << endl << endl;

	cout << "When traveling, you can choose how quickly you move. Moving fast saves time but increases the" << endl <<
	"chances of encountering problems you might have avoided by being more careful. Moving slow is" << endl
	<< "safer but takes more time." << endl;
	
	cout << endl << "Press Enter to continue" << endl;
	cin.get();
} //close printHelp function


/*****************************************************************************
**quit function:
**Verify that the user chose the quit main menu option intentionally
*****************************************************************************/
int Menu::quit()
{ //open quit function
	int quit;
	cout << "Are you sure you want to quit?" << endl << "1:Yes, quit" << endl << 
	"2:No, keep playing" << endl;
	cin >> quit;
	
	while (!(quit == 1 || quit == 2))
	{ //open input validation while loop
		cin.clear();
		cin.ignore(1000, '\n');
		cout << "That is not a valid selection. Please enter 1 or 2." << endl;
		cout << endl << "1: Quit" << endl;
		cout << "2: Keep playing" << endl;
		cin >> quit;
		quit = ((int) quit/1);
	} //close input validation while loop
	cin.ignore(1000, '\n');
	
	cout << endl;
	
	return quit;
} //close quit function


/*****************************************************************************
**travelSpeed function:
**Get user input on which speed and safety level of movement they want
*****************************************************************************/
int Menu::travelSpeed()
{ //open travelSpeed function
	int travelSpeed;
	
	cout << endl;
	cout << "How quickly will you travel?" << endl;
	cout << "1:Slow and careful" << endl;
	cout << "2:Average speed and care" << endl;
	cout << "3:Fast but careless" << endl;
	cin >> travelSpeed;
	
	while (travelSpeed < 1 || travelSpeed > 3)
	{ //open input validation while loop
		cin.clear();
		cin.ignore(1000, '\n');
		cout << "That is not a valid selection. Please enter 1, 2, or 3." << endl;
		cout << endl << "1: Slow and careful" << endl;
		cout << "2: Normal" << endl;
		cout << "3: Fast but careless" << endl;
		cin >> travelSpeed;
		travelSpeed = ((int) travelSpeed/1);
	} //close input validation while loop
	cin.ignore(1000, '\n');
	
	cout << endl;
	
	return travelSpeed;
} //close travelSpeed function


/*****************************************************************************
**encounterDanger function:
**Display inventory for consideration, then get user input for how to 
**respond to the encounter presented during the calling function
*****************************************************************************/
int Menu::encounterDanger(string obsTypeIn, vector<string> vectIn, int gemNum)
{ //open encounterDanger function
	int encounterChoice = 0;
	int vectSize = vectIn.size();

	if (vectIn.empty())
	{ //open if
		cout << "You currently have no items and " << gemNum << " gems." << endl;
	} //close if
	else
	{ //open else
		cout << "Your current inventory contains: " << endl;
		for (int i=0; i<vectSize; i++)
		{ //open for
			cout << vectIn[i] << endl;
		} //close for
		cout << "You have " << gemNum << " gems." << endl;
	} //close else
	cout << endl << endl;

	cout << "How would you like to handle this situation?" << endl;
	cout << "1: Attempt to deal with it directly without using items." << endl;
	if (!vectIn.empty())
	{ //open if
		cout << "2: Attempt to use your " << vectIn[0] << "." << endl;
	} //close if
	if (vectSize > 1)
	{ //open 2nd if
		cout << "3: Attempt to use your " << vectIn[1] << "." << endl;
	} //close 2nd if
	
	cin >> encounterChoice;
	
	while (encounterChoice < 1 || encounterChoice > 3)
	{ //open input validation while loop
		cin.clear();
		cin.ignore(1000, '\n');
		cout << "That is not a valid selection. Please enter 1 to 3." << endl;
		cout << endl << "1: Resolve directly with no items" << endl;
		cout << "2: Use" << vectIn[0] << endl;
		cout << "3: Use" << vectIn[1] << endl;
		cin >> encounterChoice;
		encounterChoice = ((int) encounterChoice/1);
	} //close input validation while loop
	cin.ignore(1000, '\n');
	
	return encounterChoice;
} //close encounterDanger function


/*****************************************************************************
**victory function:
**Display victory message text
*****************************************************************************/
void Menu::victory()
{ //open victory function
	cout << endl;
	cout << "With amazing speed and skill, you have retrieved the gems you needed and returned to" << endl
	<< "the ancient pyramid before the other search parties. Quickly, you climb to the top. Pausing" << endl
	<< "for just a moment to ensure your competitors are nowhere in sight, you insert your three" << endl
	<< "specialized gems into the recesses in the altar." << endl << endl;
	
	cout << "As soon as the last gem is in place, the altar rotates counterclockwise revealing an opening." << endl
	<< "There is a ramp leading down into the center along the right side, with a torch conveniently" << endl
	<< "mounted inside. As you move to enter you see that, for now, the bright sunlight shines into" << endl
	<< "a vast chamber below gleaming off mounds of gold, silver, and precious stones of every color." << endl
	<< "You can't believe how much wealth is here, yours now for the taking." << endl << endl;
	
	cout << "You think even a famed Spanish galleon couldn't hold all of this treasure at once! Then" << endl
	<< "you remember you don't have ANY ship to carry your new fortune, or yourself, back to civilization." << endl;
	
	cout << endl << "Perhaps something from this hoard can help you buy one of these ships conveniently" << endl
	<< "sitting offshore, or help you take them over..." << endl << endl;
	
	cout << endl << "CONGRATULATIONS!!! You have won the treasure hunt!" << endl
	<< "Join us again in Island O' Treasure 2: The Search for More Money" << endl;
	
	cout << endl << "Press Enter to continue" << endl;
	cin.get();
} //close victory function