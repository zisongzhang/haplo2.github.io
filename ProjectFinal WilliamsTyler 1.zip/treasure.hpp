/******************************************************************** 
** Author: Tyler Williams
** Date: 6-12-18
** Description: The Treasure class is a subclass to the Space class.
** It constructs Treasure objects with inherited data from Space. 
** It has a virtual function for getting a data member, setting a data
** member and destruction. It also has a unique function for triggering
** the game to change phases into the real game.
*********************************************************************/
#ifndef TREASURE_HPP
#define TREASURE_HPP

#include <iostream>

#include "space.hpp"

using std::cout;
using std::endl;

class Treasure : public Space
{
private:
	char baseSpaceChar;
	
public:
	Treasure();
	Treasure(char, int, bool, char);
	virtual char getBaseSpaceChar();
	virtual void setObsType();
	bool bigTActivate();
	virtual ~Treasure()
	{
	}
	
};
#include "treasure.cpp"
#endif