/******************************************************************** 
** Author: Tyler Williams
** Date: 6-12-18
** Description: This Danger class has functions to construct a Danger 
** object and conduct full location-based encounters, as well as a 
** destructor.
*********************************************************************/
#ifndef DANGER_HPP
#define DANGER_HPP

#include <iostream>
#include <string>
#include <vector>
#include <cstdlib>

#include "menu.hpp"

using std::cin;
using std::cout;
using std::endl;
using std::string;
using std::vector;

class Danger
{
private:
	string dangerName;

public:
	Danger();
	Danger(string);
	int encounterTreas(string, Menu, vector<string>, int);
	int resolveTreas(int, string, vector<string>, bool &);
	int encounterTerr(string, Menu, vector<string>, int);
	int resolveTerr(int, string, vector<string>, bool &);
	~Danger()
	{
	};
};
#include "danger.cpp"
#endif