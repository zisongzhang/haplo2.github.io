/******************************************************************** 
** Author: Tyler Williams
** Date: 6-12-18
** Description: The Game class is the brains and control of the program.
** It has many private data members to track progress and choose 
** correct functions to call. It has pointer variables of different
** Space classes/subclasses to manipulate data throughout the program.
** It has functions to control the flow of the game, intialize variables
** move the player, update the inventory, print the inventory, and free
** memory.
**
** It will initialize data, build the game board, and loop through all 
** commands until the player quits, wins, or loses. The player moves,
** has dangerous random encounters, searches for items and treasure,
** races against the timer of other searchers who remove treasure from 
** the board, and has to return to the big treasure before time runs out.
*********************************************************************/
#include <iostream>
#include <string>
#include <cstdlib>

#include "game.hpp"

using std::cout;
using std::endl;
using std::string;


/*****************************************************************************
**Control function:
**This function sequences the entire game. It initializes data, builds the board,
**moves the character, checks data values and game ending conditions, all by 
**calling other functions.
*****************************************************************************/
void Game::control(Menu gameMenu)
{ //open control function
	vector<string> invVect; //declare inventory
	
	//set board size
	rowMax = 20;
	colMax = 20;

	//dynamically allocate array size
	Space*** boardArray = new Space**[rowMax];
	for(int i=0; i<rowMax; i++)
	{ //open for loop
		boardArray[i] = new Space*[colMax];
	} //close for loop

	initialize(invVect); //initialize data
	
	Board islandMap(boardArray, rowMax, colMax, playerRow, playerCol); //initialize game board

	player1 = new PlayerSpace('P', 0, false, boardArray, playerRow, playerCol); //initialize player space obj

	//This section is the heart of the game. It controls the flow of the game and plays until victory, end
	//of timer, or user quits
	while ((victory != true) && (defeat != true) && (optionNum != 9))
	{ //open game control quit option while loop
		//section for before player reaches X at first; no timer & no inventory/search
		if (startTimer == false) 
		{ //open timer false if
		
			//move around the island with no action until you reach the X, which triggers the next phase of the game
			optionNum = moveOptionStart(gameMenu, islandMap, boardArray, rowMax, colMax, playerRow, playerCol); 
			
			if (boardArray[playerRow][playerCol]->getBoardChar() == 'X') //user reaches Treasure, set values and switch to new phase of game
			{ //open first Big Treasure if
				boardArray[playerRow][playerCol] = bigT;
				startTimer = bigT->bigTActivate(); //activate timer for next turn
				bigT->setSearched(true); //prevent user from finding inventory items at X location
				
				//find smallest total distance between player and new Treasure object in array
				nearestDiff = islandMap.showGems(boardArray, rowMax, colMax, playerRow, playerCol); //populate map with x's and generate # for basis of turns

				//turnNum = 30; //set max turn value (alternate option, constant value)
				turnNum = nearestDiff * 6; //set max turn value (as factor of distance to travel)
				
				islandMap.printBoard(boardArray, rowMax, colMax, playerRow, playerCol);
				maxTurns = turnNum;
				cout << endl << endl << "Thinking quickly you realize that on an island this size," << endl
				<< "it can't take 2 search parties more than " << maxTurns << " hours" << endl
				<< "to find the gems they need." << endl << endl;
				
				cout << "Press Enter to continue" << endl;
				cin.get();
			} //close first Big Treasure if
		} //close timer false if
		else if (startTimer == true) //control for the main phase of the game, can win or lose, uses timer
		{ //open timer true else if
			string currentObs;

			timeSpent = boardArray[playerRow][playerCol]->getMoveSpeed();
			
			//Remove small Treasures from Board at timer threshholds (race the clock!)
			if ((turnNum <= (2*(maxTurns/3))) && (firstGemRemoval == false))
			{ //open first removing gems if
				cout << "Your search has taken a long time. Your competitors must have found some gems by now" << endl;
				cout << endl << "Press Enter to continue" << endl;
				cin.get();
				firstGemRemoval = true; //make sure it only calls once
				islandMap.timerFindGems(boardArray, rowMax, colMax, playerRow, playerCol);
			} //close first removing gems if
			else if ((turnNum <= maxTurns/3) && (secondGemRemoval == false))
			{ //open first removing gems if
				cout << "Your search has taken a long time. Your competitors must have found more gems by now" << endl;
				cout << endl << "Press Enter to continue" << endl;
				cin.get();
				secondGemRemoval = true; //make sure it only calls once
				islandMap.timerFindGems(boardArray, rowMax, colMax, playerRow, playerCol);
			} //close first removing gems if
			
			//move around the island, get player action choice for use below
			optionNum = moveOption(gameMenu, islandMap, invVect, boardArray, rowMax, colMax, playerRow, playerCol, turnNum);
			
			//reduce timer based on movement/Terrain
			if (optionNum < 5)
			{ //open timer if
				turnNum = turnNum - timeSpent;
			} //close timer if
			
			//if player doesn't have all 3 gems, initiate possible encounters based on location and move speed choice
			if ((optionNum < 9) && (gemNum < 3))
			{ //open danger if
				int obsChoice;
				char terrainChar;
				bool safe;
				
				currentObs = boardArray[playerRow][playerCol]->getObsType();
				safe = boardArray[playerRow][playerCol]->getPassed();
				
				//if an obstacle was set randomly during movement and player hasn't already been to that location, have encounter
				if ((currentObs != "") && (safe == false)) 
				{ //open encounter if
					terrainChar = boardArray[playerRow][playerCol]->getBoardChar();
					
					Danger *currentDanger = new Danger(currentObs);
					if (terrainChar == 'x')
					{ //open small treasure resolution if
						//find out which type of obstacle will be encountered
						obsChoice = currentDanger->encounterTreas(currentObs, gameMenu, invVect, gemNum);
						
						//complete encounter and update timer with impact of result
						timeSpent = currentDanger->resolveTreas(obsChoice, currentObs, invVect, defeat);
						turnNum = turnNum - timeSpent;
						
						gemNum++; //having completed an encounter at a small treasure, gain a gem
						
						//remove 'x' from map as the gem is no longer available here
						terrainChar = boardArray[playerRow][playerCol]->getBaseSpaceChar();
						boardArray[playerRow][playerCol]->setBoardChar(terrainChar);
					} //close small treasure resolution if
					else if (!((terrainChar == 'x') && (terrainChar == 'X')))
					{ //open terrain resolution else if
						//find out which type of obstacle will be encountered
						obsChoice = currentDanger->encounterTerr(currentObs, gameMenu, invVect, gemNum);
						
						//complete encounter and update timer with impact of result
						timeSpent = currentDanger->resolveTerr(obsChoice, currentObs, invVect, defeat);
						turnNum = turnNum - timeSpent;
					} //close terrain resolution else if
					
					//after encounter is complete, make sure no more encounters happen at this position
					boardArray[playerRow][playerCol]->setPassed(true);
					
					delete currentDanger; //free dynamically allocated memory
					currentDanger = nullptr;
				} //close encounter if
			} //close danger if
			else if ((optionNum < 9) && (gemNum == 3)) //if player has enough gems, no more encounters, just check for final treasure
			{ //open final big treasure else if
				char terrainChar;
				terrainChar = boardArray[playerRow][playerCol]->getBoardChar();
				
				if (terrainChar == 'X')
				{ //open victory if
					victory = true;
					gameMenu.victory();
				} //close victory if
			} //close final big treasure else if
			
			//victory is set before this last check of the round in case the player reaches victory at the end of time
			if (turnNum <= 0 && victory == false)
			{ //open defeat if
				defeat = true;
				cout << endl << endl << endl;
				cout << "Oh no! Your competitors have found the gems they needed and opened the treasure vault!" << endl;
				cout << "You lose." << endl;
				
				cout << "Press Enter to continue" << endl << endl;
				cin.get();
			} //close defeat if
		} //close timer true else if
	} //close game control quit option while loop
	
	//free memory
	for(int i=0; i<rowMax; i++)
		delete [] boardArray[i];
	delete [] boardArray;
	
	deleteObjs();
} //close control function


/*****************************************************************************
**initialize function:
**Set up all Game values to begin
*****************************************************************************/
void Game::initialize(vector<string> & vectIn)
{ //open initialize function
	victory = false;
	defeat = false;
	startTimer = false;
	firstGemRemoval = false;
	secondGemRemoval = false;
	optionNum = 11;
	turnNum = 50;
	gemNum = 0;
	spaceFastTime = 0;
	
	spaceW = new Terrain('~', 0, false);
	spaceM = new Terrain('^', 2, false);
	spaceJ = new Terrain('j', 2, false);
	spaceR = new Terrain('|', 1, false);
	spaceNA = new Terrain(' ', 1, false);
	bigT = new Treasure('X', 1, false, ' ');	
	
	playerRow = rowMax-2;
	playerCol = colMax/2;
	
	vectIn.clear();
} //close initialize function


/*****************************************************************************
**moveOptionStart function:
**Take user input for game actions (move or print) prior to reaching trigger
**event. Can't win or lose, no timer, no items, no encounters.
*****************************************************************************/
int Game::moveOptionStart(Menu gameMenu, Board islandMap, Space*** & boardArray, int rowMax, int colMax, int& playerRow, int& playerCol)
{ //open moveOptionStart function
	islandMap.printBoard(boardArray, rowMax, colMax, playerRow, playerCol);
	cout << endl << "1:Up  2:Right  3:Down  4:Left  8:Help  9:Quit" << endl;
	int gameAction = 11;
	cin >> gameAction; //prime read
	
	while (gameAction < 1 || gameAction > 9)
	{ //open input validation while loop
		cin.clear();
		cin.ignore(1000, '\n');
		cout << "That is not a valid selection. Please enter 1 to 4." << endl;
		cout << endl << "1: Up" << endl;
		cout << "2: Right" << endl;
		cout << "3: Down" << endl;
		cout << "4: Left" << endl;
		cin >> gameAction;
		gameAction = ((int) gameAction/1);
	} //close input validation while loop
	cin.ignore(1000, '\n');
	
	//use player input to move (1-4), print help (8), or quit (9)
	switch(gameAction)
	{ //open switch
		case 1: //move up if up is not ocean
		{ //open case 1
			if (boardArray[playerRow-1][playerCol]->getBoardChar() != '~')
			{ //open if
				playerRow--;
				player1->playerMove(boardArray, playerRow, playerCol);
			} //close if
			else
			{ //open else
				cout << "You have no ship. You cannot travel here." << endl;
			} //close else
			break;
		} //close case 1
		case 2: //move right if right is not ocean
		{ //open case 2
			if (boardArray[playerRow][playerCol+1]->getBoardChar() != '~')
			{ //open if
				playerCol++;
				player1->playerMove(boardArray, playerRow, playerCol);
			} //close if
			else
			{ //open else
				cout << "You have no ship. You cannot travel here." << endl;
			} //close else
			break;
		} //close case 2
		case 3: //move down if down is not ocean
		{ //open case 3
			if (boardArray[playerRow+1][playerCol]->getBoardChar() != '~')
			{ //open if
				playerRow++;
				player1->playerMove(boardArray, playerRow, playerCol);
			} //close if
			else
			{ //open else
				cout << "You have no ship. You cannot travel here." << endl;
			} //close else
			break;
		} //close case 3
		case 4: //move left if left is not ocean
		{ //open case 4
		if (boardArray[playerRow][playerCol-1]->getBoardChar() != '~')
			{ //open if
				playerCol--;
				player1->playerMove(boardArray, playerRow, playerCol);
			} //close if
			else
			{ //open else
				cout << "You have no ship. You cannot travel here." << endl;
			} //close else
			break;
		} //close case 4
		case 8:
		{ //open case 8
			gameMenu.printHelp();
			break;
		} //close case 8
		case 9:
		{ //open case 9
			int quit = 0;
			quit = gameMenu.quit();
			if (quit == 2)
			{ //open if
				gameAction = 11; //so no functions are triggered when processing through the main while loop
			} //close if
		} //close case 9
	} //close switch
	
	return gameAction;
} //close moveOptionStart function


/*****************************************************************************
**moveOption function:
**Take user input for game actions (move, search, or print). Timer is active,
**can win, lose, find items for inventory, print inventory, and have encounters.
**When moving, player chooses movement speed, which impacts timer and chance
**of encounter.
*****************************************************************************/
int Game::moveOption(Menu gameMenu, Board islandMap, vector<string> &vectIn, Space*** & boardArray, int rowMax, int colMax, int& playerRow, int& playerCol, int turnNum)
{ //open moveOption function
	islandMap.printBoard(boardArray, rowMax, colMax, playerRow, playerCol); //display up to date map
	cout << "Hours remaining = " << turnNum << endl; //display timer
	cout << "1:Up  2:Right  3:Down  4:Left  5:Search  7:Inventory  8:Help  9:Quit" << endl;
	int speedFactor;
	bool encounterObs;
	int obsChance;
	
	int gameAction = 11;
	cin >> gameAction; //prime read
	
	while (gameAction < 1 || gameAction > 9)
	{ //open input validation while loop
		cin.clear();
		cin.ignore(1000, '\n');
		cout << "That is not a valid selection. Please enter 1 to 4." << endl;
		cout << endl << "1: Up" << endl;
		cout << "2: Right" << endl;
		cout << "3: Down" << endl;
		cout << "4: Left" << endl;
		cin >> gameAction;
		gameAction = ((int) gameAction/1);
	} //close input validation while loop
	cin.ignore(1000, '\n');

	//use player input to move (1-4), search (5), print inventory (7), print help (8), or quit (9)
	switch(gameAction)
	{ //open switch
		case 1: //move up if up is not ocean
		{ //open case 1
			if (boardArray[playerRow-1][playerCol]->getBoardChar() != '~')
			{ //open if
				speedFactor = gameMenu.travelSpeed();
				switch(speedFactor)
				{ //open 2nd switch
					case 1: 
					{ //open 2nd case 1
						timeSpent = timeSpent * 2;
						obsChance = rand() % 6 + 1;
						if (obsChance == 1)
						{ //open 2nd if
							encounterObs = true;
						} //close 2nd if
						break;
					} //close 2nd case 1
					case 2:
					{ //open 2nd case 2
						obsChance = rand() % 3 + 1;
						if (obsChance == 1)
						{ //open 2nd if
							encounterObs = true;
						} //close 2nd if
						break;
					} //close 2nd case 2
					case 3:
					{ //open 2nd case 3
						timeSpent = timeSpent/2;
						
						//special calculation for moving fast on open ground so every other move costs 1
						//otherwise every fast move costs 0 time, an exploit
						if (boardArray[playerRow-1][playerCol]->getBoardChar() == ' ')
						{ //open space fast move if
							spaceFastTime++;
							if (spaceFastTime == 2)
							{ //open fast time adjustment if
								timeSpent = 1;
								spaceFastTime = 0;
							} //close fast time adjustment if
						} //close space fast move if

						obsChance = rand() % 3 + 1;
						if (obsChance != 3)
						{ //open 2nd if
							encounterObs = true;
						} //close 2nd if
					} //close 2nd case 3
				} //close 2nd switch
				
				playerRow--;
				player1->playerMove(boardArray, playerRow, playerCol);
				
				//every treasure location causes an encounter so the player always finds the treasure
				if (boardArray[playerRow][playerCol]->getBoardChar() == 'x')
				{ //open if
					encounterObs = true;
				} //close if
				if (encounterObs == true)
				{ //open if
					boardArray[playerRow][playerCol]->setObsType();
				} //close if
			} //close if
			else
			{ //open else
				cout << "You have no ship. You cannot travel here." << endl;
			} //close else
			break;
		} //close case 1
		case 2:  //move right if right is not ocean
		{ //open case 2
			if (boardArray[playerRow][playerCol+1]->getBoardChar() != '~')
			{ //open if
				speedFactor = gameMenu.travelSpeed();
				switch(speedFactor)
				{ //open 2nd switch
					case 1: 
					{ //open 2nd case 1
						timeSpent = timeSpent * 2;
						obsChance = rand() % 6 + 1;
						if (obsChance == 1)
						{ //open 2nd if
							encounterObs = true;
						} //close 2nd if
						break;
					} //close 2nd case 1
					case 2:
					{ //open 2nd case 2
						obsChance = rand() % 3 + 1;
						if (obsChance == 1)
						{ //open 2nd if
							encounterObs = true;
						} //close 2nd if
						break;
					} //close 2nd case 2
					case 3:
					{ //open 2nd case 3
						timeSpent = timeSpent/2;
						
						//special calculation for moving fast on open ground so every other move costs 1
						//otherwise every fast move costs 0 time, an exploit
						if (boardArray[playerRow][playerCol+1]->getBoardChar() == ' ')
						{ //open space fast move if
							spaceFastTime++;
							if (spaceFastTime == 2)
							{ //open fast time adjustment if
								timeSpent = 1;
								spaceFastTime = 0;
							} //close fast time adjustment if
						} //close space fast move if
						
						obsChance = rand() % 3 + 1;
						if (obsChance != 3)
						{ //open 2nd if
							encounterObs = true;
						} //close 2nd if
					} //close 2nd case 3
				} //close 2nd switch
				
				playerCol++;
				player1->playerMove(boardArray, playerRow, playerCol);
				
				//every treasure location causes an encounter so the player always finds the treasure
				if (boardArray[playerRow][playerCol]->getBoardChar() == 'x')
				{ //open if
					encounterObs = true;
				} //close if
				if (encounterObs == true)
				{ //open if
					boardArray[playerRow][playerCol]->setObsType();
				} //close if
			} //close if
			else
			{ //open else
				cout << "You have no ship. You cannot travel here." << endl;
			} //close else
			break;
		} //close case 2
		case 3:
		{ //open case 3
			if (boardArray[playerRow+1][playerCol]->getBoardChar() != '~')
			{ //open if
				speedFactor = gameMenu.travelSpeed();
				switch(speedFactor)
				{ //open 2nd switch
					case 1: 
					{ //open 2nd case 1
						timeSpent = timeSpent * 2;
						obsChance = rand() % 6 + 1;
						if (obsChance == 1)
						{ //open 2nd if
							encounterObs = true;
						} //close 2nd if
						break;
					} //close 2nd case 1
					case 2:
					{ //open 2nd case 2
						obsChance = rand() % 3 + 1;
						if (obsChance == 1)
						{ //open 2nd if
							encounterObs = true;
						} //close 2nd if
						break;
					} //close 2nd case 2
					case 3:
					{ //open 2nd case 3
						timeSpent = timeSpent/2;
						
						//special calculation for moving fast on open ground so every other move costs 1
						//otherwise every fast move costs 0 time, an exploit
						if (boardArray[playerRow+1][playerCol]->getBoardChar() == ' ')
						{ //open space fast move if
							spaceFastTime++;
							if (spaceFastTime == 2)
							{ //open fast time adjustment if
								timeSpent = 1;
								spaceFastTime = 0;
							} //close fast time adjustment if
						} //close space fast move if
						
						obsChance = rand() % 3 + 1;
						if (obsChance != 3)
						{ //open 2nd if
							encounterObs = true;
						} //close 2nd if
					} //close 2nd case 3
				} //close 2nd switch
				
				playerRow++;
				player1->playerMove(boardArray, playerRow, playerCol);
				
				//every treasure location causes an encounter so the player always finds the treasure
				if (boardArray[playerRow][playerCol]->getBoardChar() == 'x')
				{ //open if
					encounterObs = true;
				} //close if
				if (encounterObs == true)
				{ //open if
					boardArray[playerRow][playerCol]->setObsType();
				} //close if
			} //close if
			else
			{ //open else
				cout << "You have no ship. You cannot travel here." << endl;
			} //close else
			break;
		} //close case 3
		case 4:
		{ //open case 4
		if (boardArray[playerRow][playerCol-1]->getBoardChar() != '~')
			{ //open if
				speedFactor = gameMenu.travelSpeed();
				switch(speedFactor)
				{ //open 2nd switch
					case 1: 
					{ //open 2nd case 1
						timeSpent = timeSpent * 2;
						obsChance = rand() % 6 + 1;
						if (obsChance == 1)
						{ //open 2nd if
							encounterObs = true;
						} //close 2nd if
						break;
					} //close 2nd case 1
					case 2:
					{ //open 2nd case 2
						obsChance = rand() % 3 + 1;
						if (obsChance == 1)
						{ //open 2nd if
							encounterObs = true;
						} //close 2nd if
						break;
					} //close 2nd case 2
					case 3:
					{ //open 2nd case 3
						timeSpent = timeSpent/2;
						
						//special calculation for moving fast on open ground so every other move costs 1
						//otherwise every fast move costs 0 time, an exploit
						if (boardArray[playerRow][playerCol-1]->getBoardChar() == ' ')
						{ //open space fast move if
							spaceFastTime++;
							if (spaceFastTime == 2)
							{ //open fast time adjustment if
								timeSpent = 1;
								spaceFastTime = 0;
							} //close fast time adjustment if
						} //close space fast move if
						
						obsChance = rand() % 3 + 1;
						if (obsChance != 3)
						{ //open 2nd if
							encounterObs = true;
						} //close 2nd if
					} //close 2nd case 3
				} //close 2nd switch
				
				playerCol--;
				player1->playerMove(boardArray, playerRow, playerCol);
				
				//every treasure location causes an encounter so the player always finds the treasure
				if (boardArray[playerRow][playerCol]->getBoardChar() == 'x')
				{ //open if
					encounterObs = true;
				} //close if
				if (encounterObs == true)
				{ //open if
					boardArray[playerRow][playerCol]->setObsType();
				} //close if
			} //close if
			else
			{ //open else
				cout << "You have no ship. You cannot travel here." << endl;
			} //close else
			break;
		} //close case 4
		case 5: //find a random item and choose to add to inventory or not
		{ //open case 5
			if (boardArray[playerRow][playerCol]->getSearched() != true)
			{ //open if
				gainItem(vectIn);
				boardArray[playerRow][playerCol]->setSearched(true);
			} //close if
			else
			{ //open else
				cout << "You search around but see nothing useful here." << endl;
			} //close else
			break;
		} //close case 5
		case 7: //print inventory
		{ //open case 7
			print(vectIn);
			break;
		} //close case 7
		case 8:
		{ //open case 8
			gameMenu.printHelp();
			break;
		} //close case 8
		case 9:
		{ //open case 9
			int quit = 0;
			quit = gameMenu.quit();
			if (quit == 2)
			{ //open if
				gameAction = 11;
			} //close if
		} //close case 9
	} //close switch
	
	return gameAction;
} //close moveOption function


/*****************************************************************************
**print (vector) function:
**Print all values in vector.
*****************************************************************************/
void Game::print(vector<string> vectIn)
{ //open print vector function
	int vectSize = vectIn.size();

	if (vectIn.empty())
	{ //open if
		cout << "You currently have no items and " << gemNum << " gems." << endl;
	} //close if
	else
	{ //open else
		cout << "Your current inventory contains: " << endl;
		for (int i=0; i<vectSize; i++)
		{ //open for
			cout << vectIn[i] << endl;
		} //close for
		cout << "You have " << gemNum << " gems." << endl;
	} //close else
	cout << endl;
} //close print vector function


/*****************************************************************************
**gainItem function:
**Randomly generate # 1-6 that corresponds to an item. Get user input to add
**to inventory or not
*****************************************************************************/
int Game::gainItem(vector<string> &vectIn)
{ //open gainItem function
	int itemNum = rand() % 6 + 1; //new random value to possibly add to inventory
	string itemType;
	
	switch (itemNum)
	{ //open switch
		case 1:
		{ //open case 1
			itemType = "rope";
			break;
		} //close case 1
		case 2:
		{ //open case 2
			itemType = "shovel";
			break;
		} //close case 2
		case 3:
		{ //open case 3
			itemType = "machete";
			break;
		} //close case 3
		case 4:
		{ //open case 4
			itemType = "pickax";
			break;
		} //close case 4
		case 5:
		{ //open case 5
			itemType = "torch";
			break;
		} //close case 5
		case 6:
		{ //open case 6
			itemType = "hat";
			break;
		} //close case 6
	} //close switch
	
	cout << endl << "You have found a " << itemType << "." << endl;
	cout << "Would you like to add it to your inventory?" << endl;
	cout << "1: Yes" << endl << "2: No" << endl;
	int choice = 0;
	cin >> choice;
	
	while (!(choice == 1 || choice == 2))
	{ //open input validation while loop
		cin.clear();
		cin.ignore(1000, '\n');
		cout << "That is not a valid selection. Please enter 1 or 2." << endl;
		cout << "1: Yes" << endl;
		cout << "2: No" << endl;
		cin >> choice;
		choice = ((int) choice/1);
	} //close input validation while loop
	cin.ignore(1000, '\n');
	
	if (choice == 1)
	{ //open if
		addItem(itemType, vectIn);
	} //close if
	return itemNum;
} //close gainItem function


/*****************************************************************************
**addItem function:
**Add string of item to inventory vector if there's room. If not, get user
**input for which item will be replaced with new item
*****************************************************************************/
void Game::addItem(string itemType, vector<string> &vectIn)
{ //open addItem function
	int size = vectIn.size();
	if (size < 2)
	{ //open if
		vectIn.push_back(itemType);
	} //close if
	else if (size == 2)
	{ //open else if
		int invChoice = 0;
		cout << "You can only carry 2 items at a time." << endl;
		print(vectIn);
		cout << "Which item would you like to replace with " << itemType <<
		"?" << endl;
		cout << "1: " << vectIn[0] << endl;
		cout << "or " << endl;
		cout << "2: " << vectIn[1] << endl;
		cin >> invChoice;
		
		while (!(invChoice == 1 || invChoice == 2))
		{ //open input validation while loop
			cin.clear();
			cin.ignore(1000, '\n');
			cout << "That is not a valid selection. Please enter 1 or 2." << endl;
			cout << "1: " << vectIn[0] << endl;
			cout << "2: " << vectIn[1] << endl;
			cin >> invChoice;
			invChoice = ((int) invChoice/1);
		} //close input validation while loop
		cin.ignore(1000, '\n');
		
		if (invChoice == 1)
		{ //open 2nd if
			vectIn[0] = itemType;
		} //close 2nd if
		else if (invChoice == 2)
		{ //open 2nd else if
			vectIn[1] = itemType;
		} //close 2nd else if
	} //close else if
	else
	{ //open else
		print(vectIn);
		vectIn.clear();
		vectIn.resize(2);
	} //close else
	print(vectIn);
} //close addItem function


/*****************************************************************************
**loseItem function:
**Remove string item from inventory vector
*****************************************************************************/
void Game::loseItem(string itemType, vector<string> &vectIn)
{ //open loseItem function
	int size = vectIn.size();
	if (vectIn.empty())
	{ //open if
		print(vectIn);
	} //close if
	else if (size == 1)
	{ //open if
		vectIn.pop_back();
	} //close if
	else if (size == 2)
	{ //open else if
		if (vectIn.at(0) == itemType)
		{ //open 2nd if
			vectIn[0] = vectIn[1];
			vectIn.pop_back();
		} //close 2nd if
		else if (vectIn.at(1) == itemType)
		{ //open 2nd else if
			vectIn.pop_back();
		} //close 2nd else if
	} //close else if
	else //vector should never be larger than 2, reset
	{ //open else
		print(vectIn);
		vectIn.clear();
		vectIn.resize(2);
	} //close else
	print(vectIn);
} //close loseItem function


/*****************************************************************************
**deleteObjs function:
**This will free dynamically allocated memory to Space pointers
*****************************************************************************/
void Game::deleteObjs()
{ //open deleteObjs function
	delete spaceW;
	delete spaceM;
	delete spaceJ;
	delete spaceR;
	delete spaceNA;

	spaceW = nullptr;
	spaceM = nullptr;
	spaceJ = nullptr;
	spaceR = nullptr;
	spaceNA = nullptr;

	delete bigT;
	bigT = nullptr;
	
	delete player1;
	player1 = nullptr;
} //close deleteObjs function
