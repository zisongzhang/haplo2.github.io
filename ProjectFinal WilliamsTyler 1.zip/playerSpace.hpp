/******************************************************************** 
** Author: Tyler Williams
** Date: 6-12-18
** Description: The PlayerSpace class is a subclass to the Space class.
** It constructs PlayerSpace objects with inherited data from Space. 
** It has a virtual function for getting a data member, setting a data
** member and destruction. 
** It has unique private data members to aid in movement. It also has
** a unique function for changing the player's linked pointers during
** movement actions.
*********************************************************************/
#ifndef PLAYERSPACE_HPP
#define PLAYERSPACE_HPP

#include <iostream>
#include <string>

#include "space.hpp"

using std::cout;
using std::endl;
using std::string;

class PlayerSpace : public Space
{
private:
	int playXVal = 0;
	int playYVal = 0;
	int north;
	int east;
	int south;
	int west;
	
public:
	PlayerSpace();
	PlayerSpace(char, int, bool, Space*** &, int, int);
	virtual void setObsType();
	void playerMove(Space*** &, int, int);
	virtual char getBaseSpaceChar();
	virtual ~PlayerSpace()
	{
	}
};
#include "playerSpace.cpp"
#endif