/******************************************************************** 
** Author: Tyler Williams
** Date: 6-12-18
** Description: The Space class is the base class for Terrain, Treasure,
** and PlayerSpace. It is abstract and constructs objects to become
** derived class objects with parameters they inherit of char, int, 
** and bool. It has functions that apply to subclasses.
*********************************************************************/
#include <iostream>
#include <string>

#include "space.hpp"

using std::cout;
using std::endl;
using std::string;


/*****************************************************************************
**Space default constructor:
**Build Space object with no parameters.
*****************************************************************************/
Space::Space()
{ //open default constructor
	boardChar = ' ';
	moveSpeed = 1;
	obstacleType = "";
	passed = false;
	searched = false;
	top = nullptr;
	right = nullptr;
	bottom = nullptr;
	left = nullptr;
} //close default constructor


/*****************************************************************************
**Space constructor:
**Build Space object with char, int, and bool parameters
*****************************************************************************/
Space::Space(char bCharIn, int speedIn, bool passIn)
{ //open constructor
	boardChar = bCharIn;
	moveSpeed = speedIn;
	obstacleType = "";
	passed = passIn;
	searched = false;
	top = nullptr;
	right = nullptr;
	bottom = nullptr;
	left = nullptr;
} //close constructor


/*****************************************************************************
**getter functions:
*****************************************************************************/
char Space::getBoardChar()
{ //open getBoardChar function
	return boardChar;
} //close getBoardChar function
	

int Space::getMoveSpeed()
{ //open getMoveSpeed function
	return moveSpeed;
} //close getMoveSpeed function


string Space::getObsType()
{ //open getObsType function
	return obstacleType;
} //close getObstType function


bool Space::getPassed()
{ //open getPassed function
	return passed;
} //close getPassed function


bool Space::getSearched()
{ //open getObsType function
	return searched;
} //close getObstType function
	

/*****************************************************************************
**setter functions:
*****************************************************************************/
void Space::setBoardChar(char spaceChar)
{ //open setBoardChar function
	boardChar = spaceChar;
} //close setBoardChar function


void Space::setPassed(bool passIn)
{ //open setPassed function
	passed = passIn;
} //close setPassed function


void Space::setSearched(bool searchedIn)
{ //open setPassed function
	searched = searchedIn;
} //close setPassed function