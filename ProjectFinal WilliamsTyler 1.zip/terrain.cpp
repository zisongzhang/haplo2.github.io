/******************************************************************** 
** Author: Tyler Williams
** Date: 6-12-18
** Description: The Terrain class is a subclass to the Space class.
** It constructs Terrain objects with inherited data from Space. 
** It has a virtual function for getting a data member, setting a 
** data member, and destruction.
*********************************************************************/
#include <iostream>
#include <string>
#include <cstdlib>

#include "terrain.hpp"

using std::cout;
using std::endl;
using std::string;


/*****************************************************************************
**Terrain default constructor:
**Build Terrain object with no parameters.
*****************************************************************************/
Terrain::Terrain()
{ //open default constructor
	boardChar = ' ';
	moveSpeed = 1;
	obstacleType = "";
	passed = false;
} //close default constructor


/*****************************************************************************
**Terrain constructor:
**Build Terrain object with char, int, and bool parameters
*****************************************************************************/
Terrain::Terrain(char bCharIn, int speedIn, bool passIn) : Space(bCharIn, speedIn, passIn)
{ //open constructor
	obstacleType = "";
} //close constructor


/*****************************************************************************
**setObsType function:
**Initializes the data member variable when called. Set randomly based on 
**terrain type.
*****************************************************************************/
void Terrain::setObsType()
{ //open setObsType function
	int obsNum = 0;
	if (passed == false) //locations already encountered can't have a second encounter
	{ //open if
		if (boardChar == ' ')
		{ //open 2nd if
			obsNum = rand() % 3 + 1;
			switch (obsNum)
			{ //open switch
				case 1:
				{ //open case 1
					obstacleType = "quicksand";
					break;
				} //close case 1
				case 2:
				{ //open case 2
					obstacleType = "wild boar";
					break;
				} //close case 2
				case 3:
				{ //open case 3
					obstacleType = "sunstroke";
					break;
				} //close case 3
			} //close switch
		} //close 2nd if
		else if (boardChar == '^')
		{ //open else if
			obsNum = rand() % 3 + 1;
			switch (obsNum)
			{ //open switch
				case 1:
				{ //open case 1
					obstacleType = "cave";
					break;
				} //close case 1
				case 2:
				{ //open case 2
					obstacleType = "rockslide";
					break;
				} //close case 2
				case 3:
				{ //open case 3
					obstacleType = "crevice";
					break;
				} //close case 3
			} //close switch
		} //close else if
		else if (boardChar == 'j')
		{ //open 2nd else if
			obsNum = rand() % 3 + 1;
			switch (obsNum)
			{ //open switch
				case 1:
				{ //open case 1
					obstacleType = "overgrowth";
					break;
				} //close case 1
				case 2:
				{ //open case 2
					obstacleType = "pit";
					break;
				} //close case 2
				case 3:
				{ //open case 3
					obstacleType = "spider";
					break;
				} //close case 3
			} //close switch
		} //close 2nd else if
		else if (boardChar == '|')
		{ //open 3rd else if
			obsNum = rand() % 2 + 1;
			switch (obsNum)
			{ //open switch
				case 1:
				{ //open case 1
					obstacleType = "current";
					break;
				} //close case 1
				case 2:
				{ //open case 2
					obstacleType = "crocodile";
					break;
				} //close case 2
			} //close switch
		} //close 3rd else if
	} //close if
	else
	{ //open else
		cout << "You have already cleared this area." << endl;
		cout << "You are able to pass through without incident." << endl;
	} //close else
} //close setObsType function


/*****************************************************************************
**getBaseSpaceChar function:
*****************************************************************************/
char Terrain::getBaseSpaceChar()
{
	return boardChar;
}