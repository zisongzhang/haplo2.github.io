/******************************************************************** 
** Author: Tyler Williams
** Date: 6-12-18
** Description: The Game class is the brains and control of the program.
** It has many private data members to track progress and choose 
** correct functions to call. It has pointer variables of different
** Space classes/subclasses to manipulate data throughout the program.
** It has functions to control the flow of the game, intialize variables
** move the player, update the inventory, print the inventory, and free
** memory.
*********************************************************************/
#ifndef GAME_HPP
#define GAME_HPP

#include <iostream>
#include <string>
#include <cstdlib>
#include <vector>

#include "menu.hpp"
#include "board.hpp"
#include "space.hpp"
#include "terrain.hpp"
#include "playerSpace.hpp"
#include "treasure.hpp"
#include "danger.hpp"

using std::cout;
using std::endl;
using std::string;
using std::vector;


class Game
{
private:
	bool victory = false;
	bool defeat = false;
	bool startTimer = false;
	bool firstGemRemoval = false;
	bool secondGemRemoval = false;
	int rowMax;
	int colMax;
	int playerRow;
	int playerCol;	
	int optionNum = 0;
	int turnNum;
	int gemNum = 0;
	int maxTurns;
	int nearestDiff;
	int timeSpent;
	int spaceFastTime;
	
	Space *spaceW;
	Space *spaceM;
	Space *spaceJ;
	Space *spaceR;
	Space *spaceNA;
	PlayerSpace *player1;
	Treasure *bigT;

	void initialize(vector<string> &);
	int moveOptionStart(Menu, Board, Space*** &, int, int, int&, int&);
	int moveOption(Menu, Board, vector<string> &, Space*** &, int, int, int&, int&, int);
	int gainItem(vector<string> &);
	void addItem(string, vector<string> &);
	void loseItem(string, vector<string> &);
	
public:
	void control(Menu);
	void print(vector<string>);
	void deleteObjs();
};
#include "game.cpp"
#endif