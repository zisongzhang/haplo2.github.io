/******************************************************************** 
** Author: Tyler Williams
** Date: 6-12-18
** Description: This Board class constructs a Board object (always
** placing '~' on the outermost positions). It also prints the full
** Board when called. It replaces a specific number of random Board
** locations with new Treasure object pointers. It also then can 
** randomly remove a specific number of Treasure objects to replace
** them with the type of Terrain that used to be there. The remaining
** functions are utilities to update/replace a single position with a
** specific new type of object pointer.
*********************************************************************/
#include <iostream>
#include <string>
#include <cstdlib>
#include <vector>

#include "board.hpp"

using std::cin;
using std::cout;
using std::endl;
using std::string;
using std::vector;


/*****************************************************************************
**Board constructor:
**Build Board object receiving address of 2d array of pointers as well as int 
**parameters for the array sizes and the starting player position.  The 
**initial board is mountains (^) on the top third, jungle (j) on the left third,
**with a river (|) border, & the rest plain terrain of ( ). All of the edges
**will be ocean/sea (~).
*****************************************************************************/
Board::Board(Space*** & arrayIn, int rowMax, int colMax, int playRow, int playCol)
{ //open Board constructor
	int topThird = rowMax/3;
	int midRowThird = 2*(rowMax/3);
	int bottomThird = rowMax-(rowMax/3);
	int leftThird = colMax/3;
	int midColThird = 2*(colMax/3);
	int rightThird = 3*(colMax/3);
	
	for(int i=0; i<rowMax; i++)
	{ //open first for loop
		for(int j=0; j<colMax; j++)
		{ //open second for loop
			if ((i==0) || (i==(rowMax-1)))
			{ //open if
				arrayIn[i][j] = new Terrain('~', 0, false);
			} //close if
			else if ((j==0) || (j==(colMax-1)))
			{ //open else if
				arrayIn[i][j] = new Terrain('~', 0, false);
			} //close else if
			else if (i < topThird)
			{ //open 2nd else if
				arrayIn[i][j] = new Terrain('^', 2, false);
			} //close 2nd else if
			else if (j < leftThird)
			{ //open 2nd else if
				arrayIn[i][j] = new Terrain('j', 2, false);
//				arrayIn[i][j] = new Terrain((char)176, 2, false);
			} //close 2nd else if
			else if (j == leftThird)
			{ //open 3rd else if
				arrayIn[i][j] = new Terrain('|', 1, false);
			} //close 3rd else if
			else
			{ //open else
				arrayIn[i][j] = new Terrain;
			} //close else
		} //close second for loop
	} //close first for loop

	setBigTreasure(arrayIn, rowMax/2, colMax/2);
	setWTerrain(arrayIn, 1, 1);
	setWTerrain(arrayIn, 1, 2);
	setWTerrain(arrayIn, 1, colMax-2);
	setJTerrain(arrayIn, 10, 4);
} //close Board constructor


/*****************************************************************************
**showGems function:
**Loop through the Board array and randomly replace 7 non-ocean or big Treasure
**Spaces with Treasure
*****************************************************************************/
int Board::showGems(Space*** &arrayIn, int rowMax, int colMax, int playRow, int playCol)
{ //open showGems function
	int nearest = 100;
	int gems = 7;
	
	while (gems >= 1)
	{ //open while loop
		for(int i=0; i<rowMax; i++)
		{ //open first for loop
			for(int j=0; j<colMax; j++)
			{ //open second for loop
				if ((arrayIn[i][j]->getBoardChar() != '~') && (arrayIn[i][j]->getBoardChar() != 'X') && (gems >= 1))
				{ //open if
					int gemChance = rand() % 10 + 1; //using 10% chance to replace so new objects aren't all bunched together
					if (gemChance == 1)
					{ //open 2nd if
						setSmallTreasure(arrayIn, i, j);
						gems--;
						
						//get row and col distance between new Treasure and player
						//add them together and set the smallest total to be returned to calling function
						int tempDiff = (abs(i-playRow) + abs(j-playCol));
						if (tempDiff < nearest)
						{ //open 3rd if
							nearest = tempDiff;
						} //close 3rd if
					} //close 2nd if
				} //close if
				j++;
			} //close second for loop
			i++;
		} //close first for loop
	} //close while loop
	return nearest;
} //close showGems function


/*****************************************************************************
**printBoard function:
**Print all char values in array to screen
*****************************************************************************/
void Board::printBoard(Space*** arrayIn, int rowMax, int colMax, int playRow, int playCol)
{ //open printBoard function
	for(int i=0; i<rowMax; i++)
	{ //open first for loop
		cout << endl;
		for(int j=0; j<colMax; j++)
		{ //open 2nd for loop
			if (i==playRow && j==playCol)
			{ //open if
				cout << 'P';
			} //close if
			else
			{ //open else
				cout << arrayIn[i][j]->getBoardChar();
			} //close else
		} //close 2nd for loop
	} //close first for loop
	cout << endl;
} //close printBoard function


/*****************************************************************************
**timerFindGems function:
**When called based on timer value, find all small Treasures (x) remaining on
**Board and remove 2 of them. Leave the x closest to the player so they don't
**lose their effort to reach the next gem.
*****************************************************************************/
void Board::timerFindGems(Space*** &arrayIn, int rowMax, int colMax, int playRow, int playCol)
{ //open timerFindGems function
	int nearestDiff = 100;
	int nearestPos;
	int alreadyRemoved = 100;
	int gems = 0;
	int counter = 2;
	char terrainChar;

	for(int i=0; i<rowMax; i++)
	{ //open Row for loop
		for(int j=0; j<colMax; j++)
		{ //open Col for loop
			if (arrayIn[i][j]->getBoardChar() == 'x')
			{ //open found gem if

				gemVect.push_back(i);
				gemVect.push_back(j);
				gems++;
				
				//calculate distance to player as above so the nearest gem isn't removed
				int tempDiff = (abs(i-playRow) + abs(j-playCol));
				if (tempDiff < nearestDiff)
				{ //open position set if
					nearestDiff = tempDiff;
					nearestPos = gems;
				} //close position set if
			} //close found gem if
			j++;
		} //close Col for loop
		i++;
	} //close Row for loop

	if (gems == 1)
	{ //open gemremoval infinite loop protection if
		counter = gems;
	} //close gemremoval infinite loop protection if
	while ((gems > 0) && (counter > 0))
	{ //open 2 gem removal while
		int tempRandNum = 0;
		tempRandNum = rand() % gems + 1;
		
		/**Reroll if the result would be the protected nearest gem or the gem already rolled**/
		while ((tempRandNum == nearestPos) || (tempRandNum == alreadyRemoved))
		{ //open reroll while
			tempRandNum = rand() % gems + 1;
		} //close reroll while

		//actually replace the Treasure object with the type of Terrain that used to occupy the position
		switch(tempRandNum)
		{ //open switch
			case 1:
			{ //open case 1
				alreadyRemoved = tempRandNum;
				terrainChar = arrayIn[gemVect[0]][gemVect[1]]->getBaseSpaceChar();

				if (terrainChar == ' ')
				{ //open if
					setNATerrain(arrayIn, gemVect[0], gemVect[1]);
				} //close if
				else if (terrainChar == '|')
				{ //open if
					setRTerrain(arrayIn, gemVect[0], gemVect[1]);
				} //close if
				else if (terrainChar == '^')
				{ //open if
					setMTerrain(arrayIn, gemVect[0], gemVect[1]);
				} //close if
				else if (terrainChar == 'j')
				{ //open if
					setJTerrain(arrayIn, gemVect[0], gemVect[1]);
				} //closed if
				break;
			} //close case 1
			case 2:
			{ //open case 2
				alreadyRemoved = tempRandNum;
				terrainChar = arrayIn[gemVect[2]][gemVect[3]]->getBaseSpaceChar();

				if (terrainChar == ' ')
				{ //open if
					setNATerrain(arrayIn, gemVect[2], gemVect[3]);
				} //close if
				else if (terrainChar == '|')
				{ //open if
					setRTerrain(arrayIn, gemVect[2], gemVect[3]);
				} //close if
				else if (terrainChar == '^')
				{ //open if
					setMTerrain(arrayIn, gemVect[2], gemVect[3]);
				} //close if
				else if (terrainChar == 'j')
				{ //open if
					setJTerrain(arrayIn, gemVect[2], gemVect[3]);
				} //closed if
				break;
			} //close case 2
			case 3:
			{ //open case 3
				alreadyRemoved = tempRandNum;
				terrainChar = arrayIn[gemVect[4]][gemVect[5]]->getBaseSpaceChar();

				if (terrainChar == ' ')
				{ //open if
					setNATerrain(arrayIn, gemVect[4], gemVect[5]);
				} //close if
				else if (terrainChar == '|')
				{ //open if
					setRTerrain(arrayIn, gemVect[4], gemVect[5]);
				} //close if
				else if (terrainChar == '^')
				{ //open if
					setMTerrain(arrayIn, gemVect[4], gemVect[5]);
				} //close if
				else if (terrainChar == 'j')
				{ //open if
					setJTerrain(arrayIn, gemVect[4], gemVect[5]);
				} //closed if
				break;
			} //close case 3
			case 4:
			{ //open case 4
				alreadyRemoved = tempRandNum;
				terrainChar = arrayIn[gemVect[6]][gemVect[7]]->getBaseSpaceChar();

				if (terrainChar == ' ')
				{ //open if
					setNATerrain(arrayIn, gemVect[6], gemVect[7]);
				} //close if
				else if (terrainChar == '|')
				{ //open if
					setRTerrain(arrayIn, gemVect[6], gemVect[7]);
				} //close if
				else if (terrainChar == '^')
				{ //open if
					setMTerrain(arrayIn, gemVect[6], gemVect[7]);
				} //close if
				else if (terrainChar == 'j')
				{ //open if
					setJTerrain(arrayIn, gemVect[6], gemVect[7]);
				} //closed if
				break;
			} //close case 4
			case 5:
			{ //open case 5
				alreadyRemoved = tempRandNum;
				terrainChar = arrayIn[gemVect[8]][gemVect[9]]->getBaseSpaceChar();

				if (terrainChar == ' ')
				{ //open if
					setNATerrain(arrayIn, gemVect[8], gemVect[9]);
				} //close if
				else if (terrainChar == '|')
				{ //open if
					setRTerrain(arrayIn, gemVect[8], gemVect[9]);
				} //close if
				else if (terrainChar == '^')
				{ //open if
					setMTerrain(arrayIn, gemVect[8], gemVect[9]);
				} //close if
				else if (terrainChar == 'j')
				{ //open if
					setJTerrain(arrayIn, gemVect[8], gemVect[9]);
				} //closed if
				break;
			} //close case 5
			case 6:
			{ //open case 6
				alreadyRemoved = tempRandNum;
				terrainChar = arrayIn[gemVect[10]][gemVect[11]]->getBaseSpaceChar();

				if (terrainChar == ' ')
				{ //open if
					setNATerrain(arrayIn, gemVect[10], gemVect[11]);
				} //close if
				else if (terrainChar == '|')
				{ //open if
					setRTerrain(arrayIn, gemVect[10], gemVect[11]);
				} //close if
				else if (terrainChar == '^')
				{ //open if
					setMTerrain(arrayIn, gemVect[10], gemVect[11]);
				} //close if
				else if (terrainChar == 'j')
				{ //open if
					setJTerrain(arrayIn, gemVect[10], gemVect[11]);
				} //closed if
				break;
			} //close case 6
			case 7:
			{ //open case 7
				alreadyRemoved = tempRandNum;
				terrainChar = arrayIn[gemVect[12]][gemVect[13]]->getBaseSpaceChar();

				if (terrainChar == ' ')
				{ //open if
					setNATerrain(arrayIn, gemVect[12], gemVect[13]);
				} //close if
				else if (terrainChar == '|')
				{ //open if
					setRTerrain(arrayIn, gemVect[12], gemVect[13]);
				} //close if
				else if (terrainChar == '^')
				{ //open if
					setMTerrain(arrayIn, gemVect[12], gemVect[13]);
				} //close if
				else if (terrainChar == 'j')
				{ //open if
					setJTerrain(arrayIn, gemVect[12], gemVect[13]);
				} //closed if
				break;
			} //close case 7
		} //close switch
		counter--;
	} //close 2 gem removal while

	gemVect.clear();
} //close timerFindGems function


/*****************************************************************************
**setNATerrain function:
**Change the Space value in the array from existing terrain to Plain ( )
*****************************************************************************/
void Board::setNATerrain(Space*** & arrayIn, int rowVal, int colVal)
{ //open setNATerrain function
	delete arrayIn[rowVal][colVal];
	arrayIn[rowVal][colVal] = new Terrain(' ', 0, false);
} //close setNATerrain function
	

/*****************************************************************************
**setWTerrain function:
**Change the Space value in the array from existing terrain to Water/Sea (~)
*****************************************************************************/
void Board::setWTerrain(Space*** & arrayIn, int rowVal, int colVal)
{ //open setWTerrain function
	delete arrayIn[rowVal][colVal];
	arrayIn[rowVal][colVal] = new Terrain('~', 0, false);
} //close setWTerrain function


/*****************************************************************************
**setMTerrain function:
**Change the Space value in the array from existing terrain to Mountain (^)
*****************************************************************************/
void Board::setMTerrain(Space*** & arrayIn, int rowVal, int colVal)
{ //open setMTerrain function
	delete arrayIn[rowVal][colVal];
	arrayIn[rowVal][colVal] = new Terrain('^', 0, false);
} //close setMTerrain function


/*****************************************************************************
**setJTerrain function:
**Change the Space value in the array from existing terrain to Jungle (j)
*****************************************************************************/
void Board::setJTerrain(Space*** & arrayIn, int rowVal, int colVal)
{ //open setJTerrain function
	delete arrayIn[rowVal][colVal];
//	arrayIn[rowVal][colVal] = new Terrain((char)177, 0, false);
	arrayIn[rowVal][colVal] = new Terrain('j', 0, false);
} //close setJTerrain function


/*****************************************************************************
**setRTerrain function:
**Change the Space value in the array from existing terrain to River (|)
*****************************************************************************/
void Board::setRTerrain(Space*** & arrayIn, int rowVal, int colVal)
{ //open setRTerrain function
	delete arrayIn[rowVal][colVal];
	arrayIn[rowVal][colVal] = new Terrain('|', 0, false);
} //close setRTerrain function


/*****************************************************************************
**setBigTreasure function:
**Change the Space value in the array from existing terrain to Treasure (X)
*****************************************************************************/
void Board::setBigTreasure(Space*** & arrayIn, int rowVal, int colVal)
{ //open setBigTreasure function
	char tempChar = arrayIn[rowVal][colVal]->getBoardChar();
	delete arrayIn[rowVal][colVal];
	arrayIn[rowVal][colVal] = new Treasure('X', 1, false, tempChar);
} //close setBigTreasure function


/*****************************************************************************
**setSmallTreasure function:
**Change the Space value in the array from existing terrain to treasure (x)
*****************************************************************************/
void Board::setSmallTreasure(Space*** & arrayIn, int rowVal, int colVal)
{ //open setBigTreasure function
	char tempChar = arrayIn[rowVal][colVal]->getBoardChar();
	delete arrayIn[rowVal][colVal];
	
	if (tempChar == ' ' || tempChar == '|')
	{ //open if
		arrayIn[rowVal][colVal] = new Treasure('x', 1, false, tempChar);
	} //close if
	else if (tempChar == '^' || tempChar == 'j')
	{ //open else if
		arrayIn[rowVal][colVal] = new Treasure('x', 2, false, tempChar);
	} //close else if
} //close setBigTreasure function

